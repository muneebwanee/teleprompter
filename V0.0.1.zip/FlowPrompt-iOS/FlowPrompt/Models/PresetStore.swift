import SwiftUI

struct StudioPreset: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var subtitle: String
    var icon: String
    var wpm: Double
    var fontSize: Double
    var overlayMode: Bool
    var mirrorX: Bool
    var bionicReading: Bool
    var cameraLens: String
    var cameraLUT: String
    var aspectGuide: String
}

@MainActor
final class PresetStore: ObservableObject {
    @Published var presets: [StudioPreset] = [
        StudioPreset(id: "keynote", name: "Keynote Stage", subtitle: "48pt • 145 WPM • Studio Black", icon: "mic.fill", wpm: 145, fontSize: 48, overlayMode: false, mirrorX: false, bionicReading: false, cameraLens: "1x", cameraLUT: "Natural", aspectGuide: "16:9"),
        StudioPreset(id: "vlog_overlay", name: "4K Camera Overlay", subtitle: "38pt • 155 WPM • Lens HUD", icon: "camera.viewfinder", wpm: 155, fontSize: 38, overlayMode: true, mirrorX: false, bionicReading: true, cameraLens: "1x", cameraLUT: "Warm Studio", aspectGuide: "16:9"),
        StudioPreset(id: "beamsplitter", name: "Beam-Splitter Hood", subtitle: "54pt • 140 WPM • Mirror X", icon: "arrow.left.and.right.righttriangle.left.righttriangle.right.fill", wpm: 140, fontSize: 54, overlayMode: false, mirrorX: true, bionicReading: false, cameraLens: "2x", cameraLUT: "Natural", aspectGuide: "None"),
        StudioPreset(id: "vertical_reels", name: "9:16 Vertical Creator", subtitle: "36pt • 165 WPM • Bionic Sync", icon: "rectangle.portrait.on.rectangle.portrait.angled", wpm: 165, fontSize: 36, overlayMode: true, mirrorX: false, bionicReading: true, cameraLens: "0.5x", cameraLUT: "Teal & Orange", aspectGuide: "9:16"),
        StudioPreset(id: "podcast", name: "Podcast & Interview", subtitle: "42pt • 135 WPM • Auto-Pause", icon: "waveform.circle.fill", wpm: 135, fontSize: 42, overlayMode: true, mirrorX: false, bionicReading: false, cameraLens: "1x", cameraLUT: "Soft Portra", aspectGuide: "Rule of Thirds")
    ]
}
