import Foundation
import SwiftUI

struct CueMarker: Identifiable, Hashable {
    let id = UUID()
    let label: String
    let lineIndex: Int
}

struct ScriptItem: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var title: String
    var category: String
    var content: String
    var targetWPM: Int
    var lastModified: Date
    var isPinned: Bool
    var notes: String

    var wordCount: Int {
        content
            .components(separatedBy: .whitespacesAndNewlines)
            .filter { !$0.isEmpty && !$0.hasPrefix("[") }
            .count
    }

    var estimatedDurationSeconds: Int {
        guard targetWPM > 0 else { return 0 }
        let baseSeconds = Int((Double(wordCount) / Double(targetWPM)) * 60.0)
        // Add 2 seconds per [PAUSE] marker
        let pauseCount = content.components(separatedBy: "[PAUSE]").count - 1
        return baseSeconds + (max(0, pauseCount) * 2)
    }

    var formattedDuration: String {
        let total = estimatedDurationSeconds
        let mins = total / 60
        let secs = total % 60
        return String(format: "%d:%02d", mins, secs)
    }

    var paragraphs: [String] {
        content
            .replacingOccurrences(of: "\r\n", with: "\n")
            .components(separatedBy: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }
}

@MainActor
final class ScriptStore: ObservableObject {
    @Published var scripts: [ScriptItem] = [] {
        didSet { save() }
    }
    @Published var selectedScriptID: UUID?

    private let storageKey = "flowprompt_scripts_v1"

    init() {
        load()
        if scripts.isEmpty {
            scripts = Self.sampleScripts
            selectedScriptID = scripts.first?.id
        }
    }

    var selectedScript: ScriptItem? {
        get {
            if let id = selectedScriptID, let found = scripts.first(where: { $0.id == id }) {
                return found
            }
            return scripts.first
        }
        set {
            guard let updated = newValue,
                  let idx = scripts.firstIndex(where: { $0.id == updated.id }) else { return }
            scripts[idx] = updated
        }
    }

    func createScript(title: String = "Untitled Script", category: String = "Keynote") -> ScriptItem {
        let newScript = ScriptItem(
            title: title,
            category: category,
            content: "Welcome to FlowPrompt.\n\n[PAUSE]\n\nStart typing or paste your script here. Use [PAUSE] for breath cues and **bold** or [EMPHASIS] to highlight key talking points during your presentation.",
            targetWPM: 140,
            lastModified: Date(),
            isPinned: false,
            notes: "Keep eye contact near the top camera lens."
        )
        scripts.insert(newScript, at: 0)
        selectedScriptID = newScript.id
        return newScript
    }

    func deleteScript(id: UUID) {
        scripts.removeAll { $0.id == id }
        if selectedScriptID == id {
            selectedScriptID = scripts.first?.id
        }
    }

    func duplicateScript(_ script: ScriptItem) {
        var copy = script
        copy.id = UUID()
        copy.title = "\(script.title) (Copy)"
        copy.lastModified = Date()
        scripts.insert(copy, at: 0)
        selectedScriptID = copy.id
    }

    private func save() {
        if let data = try? JSONEncoder().encode(scripts) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([ScriptItem].self, from: data) else { return }
        scripts = decoded
        selectedScriptID = scripts.first?.id
    }

    static let sampleScripts: [ScriptItem] = [
        ScriptItem(
            title: "Product Launch Keynote",
            category: "Keynote",
            content: """
            Good morning everyone, and thank you for joining us today.
            [PAUSE]
            Over the past year, our team asked a simple question: how can creators deliver studio-grade presentations from an iPhone or iPad without losing natural eye contact?
            [EMPHASIS] Today, we are introducing FlowPrompt — a modern, minimalist teleprompter engineered for clarity and speed.
            [PAUSE]
            Notice how this script stays anchored right near the front camera lens. Whether you are recording a YouTube video, pitching to investors on Zoom, or using a physical beam-splitter rig, your eyes stay locked on your audience.
            [SLOW]
            With Voice-Tracked Auto-Scroll, when you pause to improvise, the script waits for you. When you speed up, it follows every word on-device.
            [PAUSE]
            Let's dive into a live demonstration of what you can build next.
            """,
            targetWPM: 145,
            lastModified: Date(),
            isPinned: true,
            notes: "Smile on opening line. Pause 2 seconds after introducing FlowPrompt."
        ),
        ScriptItem(
            title: "YouTube Studio Episode #42",
            category: "YouTube",
            content: """
            Hey everyone! Welcome back to the channel.
            [PAUSE]
            In today's episode, we're breaking down the 3 essential lighting and framing tricks that immediately make mobile video look like a cinema camera.
            [EMPHASIS] First: position your teleprompter text within 15 degrees of the camera lens.
            Second: use a dark OLED background in dark rooms so your screen doesn't cast a blue glow on your glasses.
            [PAUSE]
            Third: use cue markers like [PAUSE] so your delivery sounds conversational rather than rehearsed.
            Drop a comment below with your favorite mobile filming rig, and let's get started!
            """,
            targetWPM: 155,
            lastModified: Date().addingTimeInterval(-3600 * 12),
            isPinned: false,
            notes: "Use Front Camera PiP in top-center mode."
        ),
        ScriptItem(
            title: "Quarterly Investor Update",
            category: "Executive",
            content: """
            Hello team and partners. Here is our concise three-minute update for this quarter.
            [PAUSE]
            First, customer retention reached a record high across our core enterprise segment, driven by faster onboarding workflows.
            [EMPHASIS] Second, we reduced mobile build latency by forty percent while shipping universal iPad and iPhone support.
            [PAUSE]
            In the second half of the year, our focus remains disciplined execution, high craftsmanship, and listening closely to customer feedback. Thank you for your continued partnership.
            """,
            targetWPM: 130,
            lastModified: Date().addingTimeInterval(-3600 * 36),
            isPinned: false,
            notes: "Enable Mirror Horizontal if using the 12.9-inch iPad teleprompter hood."
        )
    ]
}
