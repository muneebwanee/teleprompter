import SwiftUI

enum PrompterTheme: String, CaseIterable, Codable, Identifiable {
    case obsidianOrange = "Obsidian & Action Orange"
    case oledBlack = "OLED Studio Black"
    case broadcastAmber = "Broadcast Amber"
    case deepCharcoal = "Liquid Charcoal"

    var id: String { rawValue }

    var backgroundColor: Color {
        switch self {
        case .obsidianOrange: return Color(red: 0.024, green: 0.024, blue: 0.032)
        case .oledBlack: return Color.black
        case .broadcastAmber: return Color(red: 0.03, green: 0.02, blue: 0.01)
        case .deepCharcoal: return Color(red: 0.06, green: 0.06, blue: 0.08)
        }
    }

    var textColor: Color {
        switch self {
        case .obsidianOrange, .oledBlack: return Color(red: 0.98, green: 0.97, blue: 0.96)
        case .broadcastAmber: return Color(red: 1.0, green: 0.78, blue: 0.35)
        case .deepCharcoal: return Color(red: 0.95, green: 0.95, blue: 0.97)
        }
    }

    var accentTint: Color {
        switch self {
        case .obsidianOrange, .oledBlack, .deepCharcoal:
            return Color(red: 1.0, green: 0.42, blue: 0.0) // #FF6B00 Action Orange
        case .broadcastAmber:
            return Color(red: 1.0, green: 0.58, blue: 0.0)
        }
    }
}

enum PrompterFontDesign: String, CaseIterable, Codable, Identifiable {
    case sans = "SF Pro Display"
    case rounded = "SF Pro Rounded"
    case serif = "New York Serif"
    case mono = "SF Mono"

    var id: String { rawValue }

    var swiftUIFontDesign: Font.Design {
        switch self {
        case .sans: return .default
        case .rounded: return .rounded
        case .serif: return .serif
        case .mono: return .monospaced
        }
    }
}

enum ScrollMode: String, CaseIterable, Codable, Identifiable {
    case continuous = "Smooth Speed (WPM)"
    case voiceActivated = "Voice Scroll (On-Device)"
    case voiceLevel = "Audio Level Trigger"
    case manual = "Manual / Foot Pedal"

    var id: String { rawValue }
}

// Reusable iPadOS 27 Liquid Glass Surface Modifier
struct LiquidGlassModifier: ViewModifier {
    var cornerRadius: CGFloat = 26
    var isHighlighted: Bool = false

    func body(content: Content) -> some View {
        content
            .background(.ultraThinMaterial)
            .background(
                LinearGradient(
                    colors: isHighlighted
                        ? [Color(red: 1.0, green: 0.42, blue: 0.0).opacity(0.22), Color.black.opacity(0.45)]
                        : [Color.white.opacity(0.05), Color.black.opacity(0.45)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(
                        LinearGradient(
                            colors: isHighlighted
                                ? [Color(red: 1.0, green: 0.55, blue: 0.15).opacity(0.75), Color(red: 1.0, green: 0.42, blue: 0.0).opacity(0.2)]
                                : [Color.white.opacity(0.24), Color.white.opacity(0.05)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1
                    )
            )
            .shadow(color: Color.black.opacity(0.55), radius: 22, x: 0, y: 12)
    }
}

extension View {
    func liquidGlass(cornerRadius: CGFloat = 26, isHighlighted: Bool = false) -> some View {
        modifier(LiquidGlassModifier(cornerRadius: cornerRadius, isHighlighted: isHighlighted))
    }
}

@MainActor
final class TeleprompterSettings: ObservableObject {
    @AppStorage("fp_fontSize") var fontSize: Double = 44.0
    @AppStorage("fp_lineSpacing") var lineSpacing: Double = 14.0
    @AppStorage("fp_sideMargin") var horizontalMargin: Double = 42.0
    @AppStorage("fp_scrollSpeed") var wordsPerMinute: Double = 145.0
    @AppStorage("fp_mirrorH") var mirrorHorizontal: Bool = false
    @AppStorage("fp_mirrorV") var mirrorVertical: Bool = false
    @AppStorage("fp_eyeLinePosition") var eyeLineVerticalRatio: Double = 0.28
    @AppStorage("fp_showEyeLine") var showEyeLineGuide: Bool = true
    @AppStorage("fp_dimUnread") var focusDimmingEnabled: Bool = true
    @AppStorage("fp_countdownSeconds") var countdownSeconds: Int = 3
    @AppStorage("fp_showCameraPiP") var showCameraPreview: Bool = true
    @AppStorage("fp_cameraNearLens") var dockScriptNearTopLens: Bool = true
    @AppStorage("fp_showTimecode") var showElapsedTimer: Bool = true
    @AppStorage("fp_showCuePills") var renderCueBadges: Bool = true
    @AppStorage("fp_theme") var selectedThemeRaw: String = PrompterTheme.obsidianOrange.rawValue
    @AppStorage("fp_fontDesign") var selectedFontRaw: String = PrompterFontDesign.sans.rawValue
    @AppStorage("fp_scrollMode") var scrollModeRaw: String = ScrollMode.continuous.rawValue

    static let actionOrange = Color(red: 1.0, green: 0.42, blue: 0.0)
    static let actionOrangeGradient = LinearGradient(
        colors: [Color(red: 1.0, green: 0.54, blue: 0.17), Color(red: 0.90, green: 0.28, blue: 0.0)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    var theme: PrompterTheme {
        get { PrompterTheme(rawValue: selectedThemeRaw) ?? .obsidianOrange }
        set { selectedThemeRaw = newValue.rawValue }
    }

    var fontDesign: PrompterFontDesign {
        get { PrompterFontDesign(rawValue: selectedFontRaw) ?? .sans }
        set { selectedFontRaw = newValue.rawValue }
    }

    var scrollMode: ScrollMode {
        get { PrompterFontDesign(rawValue: selectedFontRaw) != nil ? (ScrollMode(rawValue: scrollModeRaw) ?? .continuous) : .continuous }
        set { scrollModeRaw = newValue.rawValue }
    }
}
