import SwiftUI

@main
struct FlowPromptApp: App {
    @StateObject private var scriptStore = ScriptStore()
    @StateObject private var settings = TeleprompterSettings()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(scriptStore)
                .environmentObject(settings)
                .preferredColorScheme(.dark)
        }
    }
}
