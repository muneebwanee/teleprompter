import SwiftUI
import AVFoundation

struct BroadcastCameraView: View {
    let script: ScriptItem
    @EnvironmentObject var settings: TeleprompterSettings
    @StateObject private var cameraManager = CameraRecordingManager()
    @StateObject private var voiceEngine = VoiceTrackEngine()

    @State private var selectedLens: String = "1x"
    @State private var selectedFPS: String = "4K 60"
    @State private var selectedLUT: String = "Natural"
    @State private var showGrid: Bool = true
    @State private var overlayOpacity: Double = 0.78
    @State private var activeWordIndex: Int = 0
    @State private var isPlaying: Bool = false

    private let lenses = ["0.5x", "1x", "2x", "3x", "Front"]
    private let luts = ["Natural", "Warm Studio", "Teal & Orange", "Monochrome", "Soft Portra"]

    var body: some View {
        ZStack {
            // Fullscreen iOS Camera Viewfinder
            CameraPreviewRepresentable(session: cameraManager.session)
                .ignoresSafeArea()

            // Rule of Thirds Grid Overlay
            if showGrid {
                GeometryReader { geo in
                    Path { path in
                        let w = geo.size.width
                        let h = geo.size.height
                        path.move(to: CGPoint(x: w / 3, y: 0))
                        path.addLine(to: CGPoint(x: w / 3, y: h))
                        path.move(to: CGPoint(x: (w / 3) * 2, y: 0))
                        path.addLine(to: CGPoint(x: (w / 3) * 2, y: h))
                        path.move(to: CGPoint(x: 0, y: h / 3))
                        path.addLine(to: CGPoint(x: w, y: h / 3))
                        path.move(to: CGPoint(x: 0, y: (h / 3) * 2))
                        path.addLine(to: CGPoint(x: w, y: (h / 3) * 2))
                    }
                    .stroke(Color.white.opacity(0.22), lineWidth: 1)
                }
                .ignoresSafeArea()
                .allowsHitTesting(false)
            }

            // Floating Translucent Script Overlay Docked Near Camera Lens
            VStack {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        Circle()
                            .fill(TeleprompterSettings.actionOrange)
                            .frame(width: 8, height: 8)
                        Text("LENS SCRIPT OVERLAY • \(Int(settings.wordsPerMinute)) WPM")
                            .font(.caption2.weight(.heavy))
                            .foregroundColor(TeleprompterSettings.actionOrange)
                        Spacer()
                        Slider(value: $overlayOpacity, in: 0.25...0.95)
                            .frame(width: 90)
                            .tint(TeleprompterSettings.actionOrange)
                    }

                    ScrollView {
                        Text(script.content)
                            .font(.system(size: settings.fontSize * 0.75, weight: .semibold))
                            .foregroundColor(.white)
                            .lineSpacing(8)
                    }
                    .frame(maxHeight: 220)
                }
                .padding(18)
                .background(Color.black.opacity(overlayOpacity))
                .liquidGlass(cornerRadius: 24, isHighlighted: true)
                .padding(.horizontal, 24)
                .padding(.top, 16)

                Spacer()

                // Bottom iOS Pro Camera Controls Bar
                VStack(spacing: 14) {
                    // Lens Dial (.5x, 1x, 2x, 3x, Front)
                    HStack(spacing: 10) {
                        ForEach(lenses, id: \.self) { lens in
                            Button {
                                selectedLens = lens
                                if lens == "Front" { cameraManager.flipCamera() }
                            } label: {
                                Text(lens)
                                    .font(.caption.weight(.bold))
                                    .frame(width: 40, height: 40)
                                    .background(selectedLens == lens ? TeleprompterSettings.actionOrange : Color.black.opacity(0.55))
                                    .foregroundColor(.white)
                                    .clipShape(Circle())
                            }
                        }
                    }

                    // Shutter & Pro Controls Row
                    HStack(spacing: 24) {
                        Button {
                            showGrid.toggle()
                        } label: {
                            Image(systemName: "grid")
                                .font(.title3)
                                .foregroundColor(showGrid ? TeleprompterSettings.actionOrange : .white)
                        }

                        Button {
                            cameraManager.toggleRecording()
                            isPlaying.toggle()
                        } label: {
                            ZStack {
                                Circle()
                                    .stroke(Color.white, lineWidth: 4)
                                    .frame(width: 68, height: 68)
                                RoundedRectangle(cornerRadius: cameraManager.isRecording ? 8 : 30)
                                    .fill(Color.red)
                                    .frame(width: cameraManager.isRecording ? 28 : 54, height: cameraManager.isRecording ? 28 : 54)
                            }
                        }

                        Menu {
                            ForEach(luts, id: \.self) { lut in
                                Button(lut) { selectedLUT = lut }
                            }
                        } label: {
                            Label(selectedLUT, systemImage: "camera.filters")
                                .font(.caption.weight(.semibold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .liquidGlass(cornerRadius: 16)
                        }
                    }
                }
                .padding(18)
                .liquidGlass(cornerRadius: 28)
                .padding(.horizontal, 20)
                .padding(.bottom, 12)
            }
        }
        .onAppear {
            cameraManager.configureIfNeeded()
        }
    }
}
