import SwiftUI

struct VectorMotionArtView: View {
    var speedMultiplier: Double = 1.0

    var body: some View {
        TimelineView(.animation) { timeline in
            let t = timeline.date.timeIntervalSinceReferenceDate * speedMultiplier
            Canvas { context, size in
                let midY = size.height * 0.5
                let width = size.width

                for layer in 0..<3 {
                    var path = Path()
                    let amp = CGFloat(14 + layer * 8)
                    let freq = Double(layer + 1) * 0.018
                    let phase = t * (1.2 + Double(layer) * 0.4)

                    path.move(to: CGPoint(x: 0, y: midY))
                    for x in stride(from: 0, through: width, by: 4) {
                        let y = midY + sin(Double(x) * freq + phase) * amp * cos(Double(x) * 0.006 - phase * 0.5)
                        path.addLine(to: CGPoint(x: x, y: y))
                    }

                    let opacity = 0.75 - Double(layer) * 0.22
                    context.stroke(
                        path,
                        with: .linearGradient(
                            Gradient(colors: [
                                Color(red: 1.0, green: 0.56, blue: 0.22).opacity(opacity),
                                Color(red: 1.0, green: 0.34, blue: 0.0).opacity(opacity * 0.5)
                            ]),
                            startPoint: CGPoint(x: 0, y: midY),
                            endPoint: CGPoint(x: width, y: midY)
                        ),
                        lineWidth: CGFloat(2.5 - Double(layer) * 0.5)
                    )
                }
            }
        }
    }
}
