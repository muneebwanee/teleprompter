import SwiftUI

struct TeleprompterView: View {
    let script: ScriptItem
    @EnvironmentObject var settings: TeleprompterSettings
    @Environment(\.dismiss) private var dismiss

    @StateObject private var voiceEngine = VoiceTrackEngine()
    @StateObject private var cameraManager = CameraRecordingManager()

    @State private var isPlaying: Bool = false
    @State private var countdownRemaining: Int = 0
    @State private var scrollOffset: CGFloat = 0.0
    @State private var activeParagraphIndex: Int = 0
    @State private var elapsedSeconds: Int = 0
    @State private var showControlsHUD: Bool = true

    private let frameTimer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()
    private let secondTimer = Timer.publish(every: 1.0, on: .main, in: .common).autoconnect()

    var paragraphs: [String] {
        script.paragraphs
    }

    var body: some View {
        GeometryReader { geo in
            ZStack {
                settings.theme.backgroundColor
                    .ignoresSafeArea()

                // Main Scrolling Prompter Area
                ScrollViewReader { proxy in
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack(alignment: .leading, spacing: settings.lineSpacing + 14) {
                            Spacer()
                                .frame(height: geo.size.height * settings.eyeLineVerticalRatio)

                            ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, line in
                                paragraphRow(index: index, text: line)
                                    .id(index)
                                    .onTapGesture {
                                        withAnimation(.easeInOut(duration: 0.25)) {
                                            activeParagraphIndex = index
                                            proxy.scrollTo(index, anchor: UnitPoint(x: 0.5, y: settings.eyeLineVerticalRatio))
                                        }
                                    }
                            }

                            Spacer()
                                .frame(height: geo.size.height * 0.72)
                        }
                        .padding(.horizontal, settings.horizontalMargin)
                        .offset(y: settings.scrollMode == .continuous ? -scrollOffset : 0)
                    }
                    .scaleEffect(
                        x: settings.mirrorHorizontal ? -1.0 : 1.0,
                        y: settings.mirrorVertical ? -1.0 : 1.0
                    )
                    .onChange(of: voiceEngine.matchedParagraphIndex) { newIdx in
                        guard settings.scrollMode == .voiceActivated else { return }
                        withAnimation(.easeInOut(duration: 0.35)) {
                            activeParagraphIndex = newIdx
                            proxy.scrollTo(newIdx, anchor: UnitPoint(x: 0.5, y: settings.eyeLineVerticalRatio))
                        }
                    }
                }

                // Eye-Line Reading Guide Overlay
                if settings.showEyeLineGuide {
                    eyeLineOverlay(in: geo)
                }

                // Top Lens Anchor & Camera PiP Overlay
                VStack {
                    topStudioBar
                    Spacer()
                    if showControlsHUD {
                        bottomControlDeck
                    }
                }
                .padding()

                // Countdown Overlay
                if countdownRemaining > 0 {
                    ZStack {
                        Color.black.opacity(0.72).ignoresSafeArea()
                        VStack(spacing: 12) {
                            Text("\(countdownRemaining)")
                                .font(.system(size: 110, weight: .bold, design: .rounded))
                                .foregroundColor(.white)
                            Text("Lock eyes on the camera lens")
                                .font(.headline)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
            .contentShape(Rectangle())
            .onTapGesture(count: 2) {
                togglePlayPause()
            }
            .onTapGesture(count: 1) {
                withAnimation(.easeInOut(duration: 0.2)) {
                    showControlsHUD.toggle()
                }
            }
        }
        .statusBar(hidden: true)
        .onAppear {
            UIApplication.shared.isIdleTimerDisabled = true
            settings.wordsPerMinute = Double(script.targetWPM)
            if settings.showCameraPreview {
                cameraManager.configureIfNeeded()
            }
        }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
            voiceEngine.stop()
            cameraManager.stopSession()
        }
        .onReceive(frameTimer) { _ in
            guard isPlaying && countdownRemaining == 0 else { return }
            let pixelsPerSecond = CGFloat(settings.wordsPerMinute) * CGFloat(settings.fontSize) * 0.0145
            if settings.scrollMode == .continuous {
                scrollOffset += pixelsPerSecond / 60.0
            } else if settings.scrollMode == .voiceLevel && voiceEngine.isSpeakingNow {
                scrollOffset += (pixelsPerSecond * 1.15) / 60.0
            }
        }
        .onReceive(secondTimer) { _ in
            if countdownRemaining > 0 {
                countdownRemaining -= 1
                if countdownRemaining == 0 {
                    startActiveScrolling()
                }
            } else if isPlaying {
                elapsedSeconds += 1
            }
        }
    }

    @ViewBuilder
    private func paragraphRow(index: Int, text: String) -> some View {
        let isCueOnly = text.hasPrefix("[") && text.hasSuffix("]")
        let isFocused = !settings.focusDimmingEnabled || abs(index - activeParagraphIndex) <= 1 || settings.scrollMode == .continuous

        if isCueOnly && settings.renderCueBadges {
            HStack(spacing: 8) {
                Image(systemName: "waveform.badge.mic")
                Text(text.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: ""))
                    .font(.system(size: max(16, settings.fontSize * 0.45), weight: .bold, design: .rounded))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 6)
            .background(settings.theme.accentTint.opacity(0.24))
            .foregroundColor(settings.theme.accentTint)
            .clipShape(Capsule())
        } else {
            Text(cleanDisplayLine(text))
                .font(.system(
                    size: settings.fontSize,
                    weight: text.contains("[EMPHASIS]") ? .bold : .semibold,
                    design: settings.fontDesign.swiftUIFontDesign
                ))
                .foregroundColor(
                    text.contains("[EMPHASIS]")
                        ? settings.theme.accentTint
                        : settings.theme.textColor.opacity(isFocused ? 1.0 : 0.35)
                )
                .lineSpacing(settings.lineSpacing)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func cleanDisplayLine(_ raw: String) -> String {
        raw.replacingOccurrences(of: "[EMPHASIS]", with: "")
           .trimmingCharacters(in: .whitespaces)
    }

    private func eyeLineOverlay(in geo: GeometryProxy) -> some View {
        let yPos = geo.size.height * settings.eyeLineVerticalRatio
        return ZStack {
            Rectangle()
                .fill(settings.theme.accentTint.opacity(0.08))
                .frame(height: settings.fontSize * 2.1)
                .overlay(
                    HStack {
                        Image(systemName: "arrowtriangle.right.fill")
                            .foregroundColor(settings.theme.accentTint)
                            .padding(.leading, 8)
                        Spacer()
                        Image(systemName: "arrowtriangle.left.fill")
                            .foregroundColor(settings.theme.accentTint)
                            .padding(.trailing, 8)
                    }
                )
                .position(x: geo.size.width / 2, y: yPos)
        }
        .allowsHitTesting(false)
    }

    private var topStudioBar: some View {
        HStack(spacing: 14) {
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .foregroundColor(.white.opacity(0.85))
            }

            if settings.showElapsedTimer {
                HStack(spacing: 6) {
                    Circle()
                        .fill(isPlaying ? Color.red : Color.gray)
                        .frame(width: 8, height: 8)
                    Text(String(format: "%02d:%02d", elapsedSeconds / 60, elapsedSeconds % 60))
                        .font(.system(.subheadline, design: .monospaced).weight(.semibold))
                        .foregroundColor(.white)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
            }

            // Live Speech / Mic Meter Badge
            if voiceEngine.isListening {
                HStack(spacing: 6) {
                    Image(systemName: voiceEngine.isSpeakingNow ? "waveform.circle.fill" : "mic.fill")
                        .foregroundColor(voiceEngine.isSpeakingNow ? .green : .secondary)
                    Text(settings.scrollMode == .voiceActivated ? "Voice Lock" : "Audio Trigger")
                        .font(.caption.weight(.semibold))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
            }

            Spacer()

            // Optional Camera PiP Next to Top Lens
            if settings.showCameraPreview {
                ZStack(alignment: .bottomTrailing) {
                    CameraPreviewRepresentable(session: cameraManager.session)
                        .frame(width: 110, height: 68)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(cameraManager.isRecording ? Color.red : Color.white.opacity(0.3), lineWidth: 2)
                        )

                    Button {
                        cameraManager.toggleRecording()
                    } label: {
                        Image(systemName: cameraManager.isRecording ? "stop.circle.fill" : "record.circle")
                            .font(.title3)
                            .foregroundColor(cameraManager.isRecording ? .red : .white)
                            .padding(4)
                    }
                }
            }
        }
    }

    private var bottomControlDeck: some View {
        VStack(spacing: 12) {
            HStack(spacing: 18) {
                // Restart button
                Button {
                    withAnimation(.spring()) {
                        scrollOffset = 0
                        activeParagraphIndex = 0
                        elapsedSeconds = 0
                    }
                } label: {
                    Image(systemName: "backward.end.fill")
                        .font(.title3)
                }

                // Play / Pause Primary Button
                Button {
                    togglePlayPause()
                } label: {
                    Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                        .font(.system(size: 52))
                        .foregroundColor(settings.theme.accentTint)
                }

                // Mirror H Toggle
                Button {
                    settings.mirrorHorizontal.toggle()
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "arrow.left.and.right.righttriangle.left.righttriangle.right")
                        Text("Mirror X")
                            .font(.caption2)
                    }
                    .foregroundColor(settings.mirrorHorizontal ? settings.theme.accentTint : .white)
                }

                // Mirror V Toggle
                Button {
                    settings.mirrorVertical.toggle()
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "arrow.up.and.down.righttriangle.up.righttriangle.down")
                        Text("Mirror Y")
                            .font(.caption2)
                    }
                    .foregroundColor(settings.mirrorVertical ? settings.theme.accentTint : .white)
                }

                // Scroll Mode Selector
                Menu {
                    ForEach(ScrollMode.allCases) { mode in
                        Button {
                            settings.scrollMode = mode
                            if isPlaying {
                                configureVoiceIfNeeded()
                            }
                        } label: {
                            Label(
                                mode.rawValue,
                                systemImage: settings.scrollMode == mode ? "checkmark" : "waveform"
                            )
                        }
                    }
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "waveform.and.mic")
                        Text("Mode")
                            .font(.caption2)
                    }
                    .foregroundColor(.white)
                }
            }

            // Speed & Font Size Sliders
            HStack(spacing: 16) {
                HStack(spacing: 8) {
                    Image(systemName: "speedometer")
                        .font(.caption)
                    Slider(value: $settings.wordsPerMinute, in: 60...260, step: 5)
                    Text("\(Int(settings.wordsPerMinute)) WPM")
                        .font(.caption.monospacedDigit())
                        .frame(width: 64, alignment: .trailing)
                }

                HStack(spacing: 8) {
                    Image(systemName: "textformat.size")
                        .font(.caption)
                    Slider(value: $settings.fontSize, in: 22...76, step: 2)
                    Text("\(Int(settings.fontSize))pt")
                        .font(.caption.monospacedDigit())
                        .frame(width: 40, alignment: .trailing)
                }
            }
            .foregroundColor(.white)
        }
        .padding(16)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }

    private func togglePlayPause() {
        if isPlaying {
            isPlaying = false
            voiceEngine.stop()
        } else {
            if scrollOffset == 0 && settings.countdownSeconds > 0 {
                countdownRemaining = settings.countdownSeconds
            } else {
                startActiveScrolling()
            }
        }
    }

    private func startActiveScrolling() {
        isPlaying = true
        configureVoiceIfNeeded()
    }

    private func configureVoiceIfNeeded() {
        if settings.scrollMode == .voiceActivated || settings.scrollMode == .voiceLevel {
            voiceEngine.requestPermissionsAndStart(paragraphs: paragraphs)
        } else {
            voiceEngine.stop()
        }
    }
}
