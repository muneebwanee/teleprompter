import SwiftUI

struct ScriptEditorView: View {
    @Binding var script: ScriptItem
    @EnvironmentObject var settings: TeleprompterSettings
    var onStartPrompter: () -> Void
    var onOpenSettings: () -> Void

    private let categories = ["Keynote", "YouTube", "Executive", "Podcast"]

    var body: some View {
        VStack(spacing: 14) {
            // Top Floating Liquid Glass Ornament Header
            VStack(spacing: 12) {
                HStack(spacing: 12) {
                    TextField("Script Title", text: $script.title)
                        .font(.title2.weight(.bold))
                        .textFieldStyle(.plain)

                    Picker("Category", selection: $script.category) {
                        ForEach(categories, id: \.self) { cat in
                            Text(cat).tag(cat)
                        }
                    }
                    .pickerStyle(.menu)
                    .tint(TeleprompterSettings.actionOrange)

                    Button {
                        script.isPinned.toggle()
                    } label: {
                        Image(systemName: script.isPinned ? "pin.fill" : "pin")
                            .foregroundColor(script.isPinned ? TeleprompterSettings.actionOrange : .secondary)
                    }
                    .buttonStyle(.bordered)
                }

                HStack(spacing: 12) {
                    metricPill(icon: "text.alignleft", label: "\(script.wordCount) words")
                    metricPill(icon: "timer", label: "Est. \(script.formattedDuration)")

                    HStack(spacing: 6) {
                        Image(systemName: "speedometer")
                            .font(.caption)
                            .foregroundColor(TeleprompterSettings.actionOrange)
                        Text("\(script.targetWPM) WPM")
                            .font(.caption.weight(.bold))
                        Stepper("", value: $script.targetWPM, in: 60...260, step: 5)
                            .labelsHidden()
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 4)
                    .background(Color.white.opacity(0.06))
                    .clipShape(Capsule())

                    Spacer()

                    Button {
                        onOpenSettings()
                    } label: {
                        Label("Studio Setup", systemImage: "slider.horizontal.3")
                            .font(.subheadline.weight(.semibold))
                    }
                    .buttonStyle(.bordered)

                    Button {
                        onStartPrompter()
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: "play.fill")
                            Text("Start Prompter")
                                .fontWeight(.bold)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 9)
                        .background(TeleprompterSettings.actionOrangeGradient)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                        .shadow(color: TeleprompterSettings.actionOrange.opacity(0.45), radius: 12, x: 0, y: 6)
                    }
                    .buttonStyle(.plain)
                }

                // Studio Cue Ribbon
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        Text("STUDIO CUES")
                            .font(.system(size: 10, weight: .heavy))
                            .foregroundColor(.secondary)

                        cueInsertButton("[PAUSE]", icon: "pause.circle.fill")
                        cueInsertButton("[EMPHASIS]", icon: "sparkles")
                        cueInsertButton("[SLOW]", icon: "tortoise.fill")
                        cueInsertButton("[FAST]", icon: "hare.fill")
                        cueInsertButton("[LOOK AT LENS]", icon: "eye.fill")
                    }
                }
            }
            .padding(18)
            .liquidGlass(cornerRadius: 26)

            // Main Glass Script Editor Card
            TextEditor(text: $script.content)
                .font(.system(size: 20, weight: .regular, design: settings.fontDesign.swiftUIFontDesign))
                .lineSpacing(9)
                .padding(20)
                .scrollContentBackground(.hidden)
                .liquidGlass(cornerRadius: 26)
        }
        .padding(16)
        .background(Color(red: 0.024, green: 0.024, blue: 0.032))
        .navigationBarTitleDisplayMode(.inline)
    }

    private func metricPill(icon: String, label: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundColor(TeleprompterSettings.actionOrange)
            Text(label)
                .font(.caption.weight(.bold))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color.white.opacity(0.06))
        .clipShape(Capsule())
    }

    private func cueInsertButton(_ tag: String, icon: String) -> some View {
        Button {
            script.content += "\n\(tag)\n"
            script.lastModified = Date()
        } label: {
            Label(tag, systemImage: icon)
                .font(.caption.weight(.bold))
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(TeleprompterSettings.actionOrange.opacity(0.16))
                .foregroundColor(Color(red: 1.0, green: 0.68, blue: 0.42))
                .overlay(
                    Capsule()
                        .stroke(TeleprompterSettings.actionOrange.opacity(0.38), lineWidth: 1)
                )
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}
