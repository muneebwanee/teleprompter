import Foundation
import Speech
import AVFoundation

@MainActor
final class VoiceTrackEngine: ObservableObject {
    @Published var isListening: Bool = false
    @Published var recognizedTranscript: String = ""
    @Published var matchedParagraphIndex: Int = 0
    @Published var audioLevelDB: Float = -60.0
    @Published var isSpeakingNow: Bool = false
    @Published var permissionError: String?

    private let speechRecognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioEngine = AVAudioEngine()
    private var scriptParagraphs: [String] = []

    func requestPermissionsAndStart(paragraphs: [String]) {
        self.scriptParagraphs = paragraphs
        SFSpeechRecognizer.requestAuthorization { [weak self] authStatus in
            Task { @MainActor in
                guard let self = self else { return }
                switch authStatus {
                case .authorized:
                    self.startAudioSession()
                default:
                    self.permissionError = "Speech recognition permission not granted. Using audio-level detection fallback."
                    self.startAudioSession(speechAuthorized: false)
                }
            }
        }
    }

    private func startAudioSession(speechAuthorized: Bool = true) {
        stop()
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playAndRecord, mode: .measurement, options: [.defaultToSpeaker, .allowBluetooth])
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)

            let inputNode = audioEngine.inputNode
            let recordingFormat = inputNode.outputFormat(forBus: 0)

            if speechAuthorized, let recognizer = speechRecognizer, recognizer.isAvailable {
                let request = SFSpeechAudioBufferRecognitionRequest()
                request.shouldReportPartialResults = true
                if #available(iOS 13, *) {
                    request.requiresOnDeviceRecognition = false
                }
                self.recognitionRequest = request

                recognitionTask = recognizer.recognitionTask(with: request) { [weak self] result, error in
                    guard let self = self else { return }
                    if let result = result {
                        let spoken = result.bestTranscription.formattedString
                        Task { @MainActor in
                            self.recognizedTranscript = spoken
                            self.matchSpokenWordsToParagraph(spoken: spoken)
                        }
                    }
                    if error != nil {
                        Task { @MainActor in
                            self.stop()
                        }
                    }
                }
            }

            inputNode.removeTap(onBus: 0)
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { [weak self] buffer, _ in
                guard let self = self else { return }
                self.recognitionRequest?.append(buffer)
                let db = Self.calculateRMSLevel(buffer: buffer)
                Task { @MainActor in
                    self.audioLevelDB = db
                    self.isSpeakingNow = db > -38.0
                }
            }

            audioEngine.prepare()
            try audioEngine.start()
            isListening = true
        } catch {
            permissionError = "Unable to start microphone: \(error.localizedDescription)"
            isListening = false
        }
    }

    private func matchSpokenWordsToParagraph(spoken: String) {
        let spokenWords = spoken.lowercased()
            .components(separatedBy: .whitespacesAndNewlines)
            .suffix(8)
        guard !spokenWords.isEmpty else { return }

        let searchWindowEnd = min(scriptParagraphs.count - 1, matchedParagraphIndex + 4)
        guard matchedParagraphIndex <= searchWindowEnd else { return }

        var bestIdx = matchedParagraphIndex
        var highestOverlap = 0

        for idx in matchedParagraphIndex...searchWindowEnd {
            let paraWords = Set(
                scriptParagraphs[idx]
                    .lowercased()
                    .components(separatedBy: CharacterSet.alphanumerics.inverted)
                    .filter { $0.count > 2 }
            )
            let overlap = spokenWords.filter { paraWords.contains($0) }.count
            if overlap > highestOverlap && overlap >= 2 {
                highestOverlap = overlap
                bestIdx = idx
            }
        }

        if bestIdx > matchedParagraphIndex {
            matchedParagraphIndex = bestIdx
        }
    }

    nonisolated private static func calculateRMSLevel(buffer: AVAudioPCMBuffer) -> Float {
        guard let channelData = buffer.floatChannelData?[0] else { return -60.0 }
        let frameLength = Int(buffer.frameLength)
        guard frameLength > 0 else { return -60.0 }
        var sum: Float = 0
        for i in 0..<frameLength {
            let sample = channelData[i]
            sum += sample * sample
        }
        let rms = sqrt(sum / Float(frameLength))
        let db = 20 * log10(max(rms, 0.000_01))
        return max(-60.0, min(0.0, db))
    }

    func stop() {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        recognitionRequest?.endAudio()
        recognitionRequest = nil
        recognitionTask?.cancel()
        recognitionTask = nil
        isListening = false
        isSpeakingNow = false
    }
}
