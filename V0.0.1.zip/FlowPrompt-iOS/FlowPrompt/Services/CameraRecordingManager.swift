import Foundation
import AVFoundation
import Photos
import SwiftUI

final class CameraRecordingManager: NSObject, ObservableObject, AVCaptureFileOutputRecordingDelegate {
    @Published var session = AVCaptureSession()
    @Published var isRecording = false
    @Published var isConfigured = false
    @Published var statusMessage: String?
    @Published var usingFrontCamera = true

    private let movieOutput = AVCaptureMovieFileOutput()
    private let sessionQueue = DispatchQueue(label: "com.flowprompt.cameraQueue")

    func configureIfNeeded() {
        guard !isConfigured else { return }
        AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
            guard granted, let self = self else { return }
            self.sessionQueue.async {
                self.setupSession(front: true)
            }
        }
    }

    private func setupSession(front: Bool) {
        session.beginConfiguration()
        session.sessionPreset = .high

        session.inputs.forEach { session.removeInput($0) }

        let position: AVCaptureDevice.Position = front ? .front : .back
        if let videoDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: position),
           let videoInput = try? AVCaptureDeviceInput(device: videoDevice),
           session.canAddInput(videoInput) {
            session.addInput(videoInput)
        }

        if let audioDevice = AVCaptureDevice.default(for: .audio),
           let audioInput = try? AVCaptureDeviceInput(device: audioDevice),
           session.canAddInput(audioInput) {
            session.addInput(audioInput)
        }

        if session.outputs.isEmpty && session.canAddOutput(movieOutput) {
            session.addOutput(movieOutput)
        }

        session.commitConfiguration()
        session.startRunning()

        DispatchQueue.main.async {
            self.isConfigured = true
            self.usingFrontCamera = front
        }
    }

    func flipCamera() {
        let nextPosition = !usingFrontCamera
        sessionQueue.async { [weak self] in
            self?.setupSession(front: nextPosition)
        }
    }

    func toggleRecording() {
        if movieOutput.isRecording {
            movieOutput.stopRecording()
            DispatchQueue.main.async { self.isRecording = false }
        } else {
            let tempURL = FileManager.default.temporaryDirectory
                .appendingPathComponent("FlowPromptTake_\(Int(Date().timeIntervalSince1970)).mov")
            movieOutput.startRecording(to: tempURL, recordingDelegate: self)
            DispatchQueue.main.async { self.isRecording = true }
        }
    }

    func stopSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if self.movieOutput.isRecording {
                self.movieOutput.stopRecording()
            }
            if self.session.isRunning {
                self.session.stopRunning()
            }
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput,
                    didFinishRecordingTo outputFileURL: URL,
                    from connections: [AVCaptureConnection],
                    error: Error?) {
        guard error == nil else {
            DispatchQueue.main.async {
                self.statusMessage = "Recording stopped: \(error!.localizedDescription)"
            }
            return
        }
        PHPhotoLibrary.requestAuthorization { status in
            guard status == .authorized || status == .limited else { return }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: outputFileURL)
            }) { saved, _ in
                DispatchQueue.main.async {
                    self.statusMessage = saved ? "Video take saved to Photos" : "Could not save video take"
                }
            }
        }
    }
}

struct CameraPreviewRepresentable: UIViewRepresentable {
    let session: AVCaptureSession

    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        let previewLayer = AVCaptureVideoPreviewLayer(session: session)
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)
        return view
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        if let layer = uiView.layer.sublayers?.first as? AVCaptureVideoPreviewLayer {
            layer.session = session
            layer.frame = uiView.bounds
        }
    }
}
