import WidgetKit
import SwiftUI

struct FlowPromptWidgetEntry: TimelineEntry {
    let date: Date
    let scriptTitle: String
    let wordCount: Int
    let duration: String
    let wpm: Int
    let presetName: String
}

struct FlowPromptWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> FlowPromptWidgetEntry {
        FlowPromptWidgetEntry(date: Date(), scriptTitle: "Keynote Opening Address", wordCount: 142, duration: "0:58", wpm: 145, presetName: "4K Camera Overlay")
    }

    func getSnapshot(in context: Context, completion: @escaping (FlowPromptWidgetEntry) -> Void) {
        completion(placeholder(in: context))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<FlowPromptWidgetEntry>) -> Void) {
        let entry = placeholder(in: context)
        let timeline = Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(1800)))
        completion(timeline)
    }
}

struct FlowPromptWidgetEntryView: View {
    var entry: FlowPromptWidgetProvider.Entry
    @Environment(\.widgetFamily) var family

    private let actionOrange = Color(red: 1.0, green: 0.42, blue: 0.0)

    var body: some View {
        ZStack {
            Color(red: 0.03, green: 0.03, blue: 0.04)
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Circle()
                        .fill(actionOrange)
                        .frame(width: 8, height: 8)
                    Text("FLOWPROMPT")
                        .font(.system(size: 10, weight: .heavy))
                        .foregroundColor(actionOrange)
                    Spacer()
                    Text("\(entry.wpm) WPM")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.secondary)
                }

                Text(entry.scriptTitle)
                    .font(.headline.weight(.bold))
                    .foregroundColor(.white)
                    .lineLimit(2)

                Spacer()

                HStack {
                    Text("\(entry.wordCount)w • \(entry.duration)")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    Spacer()
                    Image(systemName: "play.circle.fill")
                        .foregroundColor(actionOrange)
                        .font(.title3)
                }
            }
            .padding(14)
        }
    }
}

struct FlowPromptWidget: Widget {
    let kind: String = "FlowPromptWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: FlowPromptWidgetProvider()) { entry in
            FlowPromptWidgetEntryView(entry: entry)
        }
        .configurationDisplayName("FlowPrompt Studio Widget")
        .description("Quick-launch pinned scripts, camera overlay mode, and speaking pace right from your iOS or iPadOS Home Screen and Lock Screen.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular])
    }
}
