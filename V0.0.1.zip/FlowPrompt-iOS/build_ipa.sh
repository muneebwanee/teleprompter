#!/usr/bin/env bash
set -euo pipefail

echo "=== Building FlowPrompt Universal iOS/iPadOS .ipa ==="

if command -v xcodegen >/dev/null 2>&1; then
  echo "[1/3] Regenerating FlowPrompt.xcodeproj via XcodeGen..."
  xcodegen generate
fi

echo "[2/3] Compiling Release arm64 build (unsigned for sideloading)..."
xcodebuild build \
  -project FlowPrompt.xcodeproj \
  -scheme FlowPrompt \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath ./build_output \
  CODE_SIGN_IDENTITY="" \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGNING_ALLOWED=NO

echo "[3/3] Packaging Payload into FlowPrompt-iOS-Universal.ipa..."
rm -rf Payload FlowPrompt-iOS-Universal.ipa
mkdir -p Payload
cp -R ./build_output/Build/Products/Release-iphoneos/FlowPrompt.app Payload/
zip -r9 FlowPrompt-iOS-Universal.ipa Payload
rm -rf Payload

echo "Done! Sideload FlowPrompt-iOS-Universal.ipa using AltStore, SideStore, or Sideloadly."
