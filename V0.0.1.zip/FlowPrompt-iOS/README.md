# FlowPrompt — Minimalist iOS & iPadOS Teleprompter

**Developed by [muneebwanee](https://github.com/muneebwanee)**

FlowPrompt is a modern, minimalist universal teleprompter app for **iPadOS and iOS**, designed with a **Dark Obsidian & Action Orange Liquid Glass** aesthetic, smooth vector motion animations, 60fps scrolling, Bionic Focus reading, optical beam-splitter mirror modes, live camera Picture-in-Picture, and voice-activated scrolling.

---

## Key Features

- **Minimalist iOS & iPadOS Liquid Glass UI**: Clean 4-tab navigation (**Scripts**, **Editor**, **Studio**, **Settings**) with frosted translucent surfaces, specular borders, and spring transitions.
- **Vector Motion Art & 60fps Optical Stage**: Smooth variable-speed WPM scrolling, adjustable eye-line focus band, and one-tap inline delivery cues (`[PAUSE 2s]`, `[EMPHASIS]`, `[SLOW PACE]`, `[BREATHE]`).
- **Bionic Focus Reading & Beam-Splitter Mirroring**: Emphasizes leading letters for effortless peripheral reading and supports horizontal (`Mirror X`) and vertical (`Mirror Y`) flips for physical teleprompter glass hoods.
- **Voice Scroll & Live Camera PiP**: Uses on-device speech recognition (`SFSpeechRecognizer` / Web Speech API) and live front-camera framing (`AVCaptureSession`) right next to the lens.
- **100% Offline Privacy + Full Legal & Settings Pages**: Built-in **Privacy Policy**, **Terms of Service**, JSON script backup/export, and hardware keyboard / Bluetooth foot-pedal shortcuts.

---

## Project Structure

```text
FlowPrompt-iOS/
├── FlowPrompt.xcodeproj/          # Universal iOS & iPadOS 16.0+ Xcode Project
├── project.yml                    # XcodeGen specification
├── build_ipa.sh                   # One-command local macOS unsigned .ipa builder
├── .github/workflows/build-ipa.yml# Automated GitHub Actions cloud .ipa compiler
├── README.md                      # Documentation & workflow guide
└── FlowPrompt/
    ├── Info.plist                 # Camera, Microphone, and Speech permissions
    ├── FlowPromptApp.swift        # App entry point
    ├── Models/
    │   ├── Script.swift           # Script model, WPM duration math, JSON persistence
    │   └── TeleprompterSettings.swift # LiquidGlassModifier & Obsidian Orange theme
    ├── Services/
    │   ├── VoiceTrackEngine.swift # On-device Speech & Audio level scrolling engine
    │   └── CameraRecordingManager.swift # AVCaptureSession PiP & video recording
    └── Views/
        ├── ContentView.swift      # Minimalist iPad/iOS navigation & script library
        ├── ScriptEditorView.swift # Distraction-free script editor & cue toolbar
        ├── TeleprompterView.swift # Full-screen 60fps prompter stage & HUD
        └── SettingsDrawerView.swift # Settings, Privacy Policy, Terms of Service & About (muneebwanee)
```

---

## Complete Build & Sideloading Workflow

### Workflow 1: Cloud `.ipa` Build via GitHub Actions (No Mac Needed)

1. Unzip `FlowPrompt_iOS_XcodeProject.zip` and push the files to a GitHub repository under your account (e.g., `github.com/muneebwanee/FlowPrompt`).
2. Open the **Actions** tab on GitHub, select **Build Unsigned FlowPrompt iOS IPA**, and click **Run workflow**.
3. Once completed (~2 minutes), download the **`FlowPrompt-iOS-Universal-IPA`** artifact containing `FlowPrompt-iOS-Universal.ipa`.
4. Sideload `FlowPrompt-iOS-Universal.ipa` onto your iPad or iPhone using:
   - **Sideloadly** (Windows / macOS): Drag the `.ipa` into Sideloadly, enter your Apple ID, and click **Start**.
   - **AltStore / SideStore** (On-Device): Open the `.ipa` from the iOS **Files** app inside AltStore or SideStore.
5. Trust your certificate under **Settings → General → VPN & Device Management**, and enable **Developer Mode** under **Settings → Privacy & Security → Developer Mode**.

### Workflow 2: Local macOS Build via Xcode or Terminal

```bash
chmod +x build_ipa.sh
./build_ipa.sh
```
Or open `FlowPrompt.xcodeproj` directly in Xcode 15+, select your Personal Team under **Signing & Capabilities**, and press **`Cmd + R`** to run on your connected iPad or iPhone.

### Workflow 3: Instant Standalone iOS/iPadOS WebApp

1. Open `FlowPrompt_Teleprompter_App.html` in **Safari** on your iPad or iPhone.
2. Tap **Share → Add to Home Screen** to install FlowPrompt as a full-screen standalone app.

---

## Credits & Author

- **Developer**: [muneebwanee](https://github.com/muneebwanee)
- **License**: MIT License
