import SwiftUI

struct ContentView: View {
    @EnvironmentObject var scriptStore: ScriptStore
    @EnvironmentObject var settings: TeleprompterSettings
    @State private var searchText: String = ""
    @State private var selectedCategory: String = "All"
    @State private var isPresentingPrompter: Bool = false
    @State private var isShowingSettingsSheet: Bool = false

    private let categories = ["All", "Keynote", "YouTube", "Executive", "Podcast"]

    var filteredScripts: [ScriptItem] {
        scriptStore.scripts.filter { item in
            let matchesCategory = (selectedCategory == "All") || (item.category == selectedCategory)
            let matchesSearch = searchText.isEmpty ||
                item.title.localizedCaseInsensitiveContains(searchText) ||
                item.content.localizedCaseInsensitiveContains(searchText)
            return matchesCategory && matchesSearch
        }
    }

    var body: some View {
        ZStack {
            // iPadOS 27 Obsidian & Action Orange Ambient Mesh Background
            Color(red: 0.024, green: 0.024, blue: 0.032)
                .ignoresSafeArea()
            RadialGradient(
                colors: [TeleprompterSettings.actionOrange.opacity(0.20), Color.clear],
                center: .topLeading,
                startRadius: 20,
                endRadius: 520
            )
            .ignoresSafeArea()

            NavigationSplitView {
                sidebarList
                    .navigationSplitViewColumnWidth(min: 300, ideal: 330, max: 370)
            } detail: {
                if let script = scriptStore.selectedScript {
                    ScriptEditorView(
                        script: Binding(
                            get: { script },
                            set: { scriptStore.selectedScript = $0 }
                        ),
                        onStartPrompter: { isPresentingPrompter = true },
                        onOpenSettings: { isShowingSettingsSheet = true }
                    )
                } else {
                    emptyDetailPlaceholder
                }
            }
            .tint(TeleprompterSettings.actionOrange)
        }
        .fullScreenCover(isPresented: $isPresentingPrompter) {
            if let script = scriptStore.selectedScript {
                TeleprompterView(script: script)
                    .environmentObject(settings)
            }
        }
        .sheet(isPresented: $isShowingSettingsSheet) {
            SettingsDrawerView()
                .environmentObject(settings)
        }
    }

    private var sidebarList: some View {
        VStack(spacing: 12) {
            // Segmented Glass Category Filter
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(categories, id: \.self) { cat in
                        Button {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.78)) {
                                selectedCategory = cat
                            }
                        } label: {
                            Text(cat)
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 13)
                                .padding(.vertical, 7)
                                .background(
                                    Capsule()
                                        .fill(
                                            selectedCategory == cat
                                                ? AnyShapeStyle(TeleprompterSettings.actionOrangeGradient)
                                                : AnyShapeStyle(Color.white.opacity(0.07))
                                        )
                                )
                                .foregroundColor(selectedCategory == cat ? .white : .secondary)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
            }

            ScrollView {
                LazyVStack(spacing: 10) {
                    ForEach(filteredScripts) { item in
                        let isSelected = (scriptStore.selectedScriptID == item.id)
                        Button {
                            scriptStore.selectedScriptID = item.id
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    if item.isPinned {
                                        Image(systemName: "pin.fill")
                                            .font(.caption2)
                                            .foregroundColor(TeleprompterSettings.actionOrange)
                                    }
                                    Text(item.title)
                                        .font(.headline.weight(.bold))
                                        .foregroundColor(.white)
                                        .lineLimit(1)
                                    Spacer()
                                    Text(item.category.uppercased())
                                        .font(.system(size: 10, weight: .heavy))
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 3)
                                        .background(TeleprompterSettings.actionOrange.opacity(0.18))
                                        .foregroundColor(TeleprompterSettings.actionOrange)
                                        .clipShape(Capsule())
                                }

                                Text(item.content.replacingOccurrences(of: "\n", with: " "))
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                    .lineLimit(2)

                                HStack(spacing: 12) {
                                    Label("\(item.wordCount)w", systemImage: "text.word.spacing")
                                    Label(item.formattedDuration, systemImage: "clock")
                                    Label("\(item.targetWPM) WPM", systemImage: "speedometer")
                                        .foregroundColor(TeleprompterSettings.actionOrange)
                                }
                                .font(.caption2.weight(.semibold))
                                .foregroundColor(.secondary)
                            }
                            .padding(14)
                            .liquidGlass(cornerRadius: 20, isHighlighted: isSelected)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 14)
            }
        }
        .background(Color(red: 0.04, green: 0.04, blue: 0.055))
        .navigationTitle("Teleprompter")
        .searchable(text: $searchText, prompt: "Search scripts or cues...")
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    isShowingSettingsSheet = true
                } label: {
                    Image(systemName: "slider.horizontal.3")
                        .foregroundColor(TeleprompterSettings.actionOrange)
                }
            }
            ToolbarItem(placement: .primaryAction) {
                Button {
                    _ = scriptStore.createScript()
                } label: {
                    Label("New Script", systemImage: "plus.circle.fill")
                        .foregroundColor(TeleprompterSettings.actionOrange)
                }
            }
        }
    }

    private var emptyDetailPlaceholder: some View {
        VStack(spacing: 16) {
            Image(systemName: "text.viewfinder")
                .font(.system(size: 56))
                .foregroundColor(TeleprompterSettings.actionOrange)
            Text("Select or Create a Studio Script")
                .font(.title3.weight(.bold))
            Button("Create New Script") {
                _ = scriptStore.createScript()
            }
            .buttonStyle(.borderedProminent)
            .tint(TeleprompterSettings.actionOrange)
        }
    }
}
