import SwiftUI

struct SettingsDrawerView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Form {
                Section("Teleprompter Stage") {
                    Picker("Scroll Engine", selection: $settings.scrollModeRaw) {
                        ForEach(ScrollMode.allCases) { mode in
                            Text(mode.rawValue).tag(mode.rawValue)
                        }
                    }
                    Stepper("Start Countdown: \(settings.countdownSeconds)s", value: $settings.countdownSeconds, in: 0...10)
                    Toggle("Dim Unfocused Lines", isOn: $settings.focusDimmingEnabled)
                    Toggle("Render Cue Badges ([PAUSE])", isOn: $settings.renderCueBadges)
                }

                Section("Appearance & Typography") {
                    Picker("Studio Theme", selection: $settings.selectedThemeRaw) {
                        ForEach(PrompterTheme.allCases) { theme in
                            Text(theme.rawValue).tag(theme.rawValue)
                        }
                    }
                    Picker("Typeface", selection: $settings.selectedFontRaw) {
                        ForEach(PrompterFontDesign.allCases) { font in
                            Text(font.rawValue).tag(font.rawValue)
                        }
                    }
                    VStack(alignment: .leading) {
                        Text("Font Size: \(Int(settings.fontSize)) pt")
                        Slider(value: $settings.fontSize, in: 24...76, step: 2)
                            .tint(TeleprompterSettings.actionOrange)
                    }
                    VStack(alignment: .leading) {
                        Text("Side Margin: \(Int(settings.horizontalMargin)) pt")
                        Slider(value: $settings.horizontalMargin, in: 16...140, step: 4)
                            .tint(TeleprompterSettings.actionOrange)
                    }
                }

                Section("Optical Beam-Splitter Rig") {
                    Toggle("Mirror Horizontally (X-Axis)", isOn: $settings.mirrorHorizontal)
                    Toggle("Mirror Vertically (Y-Axis)", isOn: $settings.mirrorVertical)
                    Toggle("Show Eye-Line Guide Band", isOn: $settings.showEyeLineGuide)
                    Toggle("Show Camera Picture-in-Picture", isOn: $settings.showCameraPreview)
                }

                Section("Legal & Studio Documentation") {
                    NavigationLink("Privacy Policy") {
                        PrivacyPolicyView()
                    }
                    NavigationLink("Terms of Service") {
                        TermsOfServiceView()
                    }
                    NavigationLink("About & Developer") {
                        AboutDeveloperView()
                    }
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                        .foregroundColor(TeleprompterSettings.actionOrange)
                }
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct PrivacyPolicyView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Privacy Policy")
                    .font(.largeTitle.weight(.bold))
                Text("Effective Date: October 14, 2026")
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                Text("1. 100% On-Device Storage")
                    .font(.headline)
                    .foregroundColor(TeleprompterSettings.actionOrange)
                Text("All scripts, cue tags, and studio preferences are saved locally on your iPhone or iPad. FlowPrompt never uploads or transmits your scripts to external servers.")

                Text("2. Camera & Microphone")
                    .font(.headline)
                    .foregroundColor(TeleprompterSettings.actionOrange)
                Text("Camera framing previews, video takes, and voice-activated scrolling run strictly on your device using Apple AVFoundation and Speech frameworks.")

                Text("3. Zero Analytics or Tracking")
                    .font(.headline)
                    .foregroundColor(TeleprompterSettings.actionOrange)
                Text("FlowPrompt contains no third-party analytics, advertising SDKs, or telemetry.")
            }
            .padding(24)
        }
        .navigationTitle("Privacy Policy")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct TermsOfServiceView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Terms of Service")
                    .font(.largeTitle.weight(.bold))
                Text("Last Updated: October 14, 2026")
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                Text("1. Usage & Ownership")
                    .font(.headline)
                    .foregroundColor(TeleprompterSettings.actionOrange)
                Text("You retain full ownership and copyright of all scripts and video recordings produced with FlowPrompt.")

                Text("2. Local Backups")
                    .font(.headline)
                    .foregroundColor(TeleprompterSettings.actionOrange)
                Text("Because FlowPrompt operates completely offline without cloud accounts, please maintain regular backups of your scripts.")

                Text("3. Warranty Disclaimer")
                    .font(.headline)
                    .foregroundColor(TeleprompterSettings.actionOrange)
                Text("FlowPrompt is provided 'as is' without warranty of any kind, express or implied.")
            }
            .padding(24)
        }
        .navigationTitle("Terms of Service")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct AboutDeveloperView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack(spacing: 16) {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .fill(TeleprompterSettings.actionOrangeGradient)
                        .frame(width: 64, height: 64)
                        .overlay(
                            Image(systemName: "viewfinder.circle.fill")
                                .font(.system(size: 32))
                                .foregroundColor(.white)
                        )
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Teleprompter")
                            .font(.title2.weight(.bold))
                        Text("Version 0.0.1 • Universal iOS & iPadOS")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                    }
                }

                Divider()

                Text("Developed by muneebwanee")
                    .font(.headline)
                    .foregroundColor(TeleprompterSettings.actionOrange)

                Text("Crafted with a minimalist Vector Motion & Liquid Glass aesthetic for iPad and iPhone creators, speakers, and studios.")
                    .foregroundColor(.secondary)

                if let url = URL(string: "https://github.com/muneebwanee") {
                    Link(destination: url) {
                        HStack {
                            Image(systemName: "link")
                            Text("github.com/muneebwanee")
                                .fontWeight(.semibold)
                            Spacer()
                            Image(systemName: "arrow.up.right")
                        }
                        .padding(16)
                        .liquidGlass(cornerRadius: 18, isHighlighted: true)
                    }
                }
            }
            .padding(24)
        }
        .navigationTitle("About")
        .navigationBarTitleDisplayMode(.inline)
    }
}
