import WidgetKit
import SwiftUI

struct TeleprompterWidgetEntry: TimelineEntry {
    let date: Date
    let scriptTitle: String
    let scriptExcerpt: String
    let wordCount: Int
    let duration: String
    let wpm: Int
}

struct TeleprompterWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> TeleprompterWidgetEntry {
        TeleprompterWidgetEntry(
            date: Date(),
            scriptTitle: "Product Launch Keynote",
            scriptExcerpt: "Good morning everyone, and thank you for joining us today. Today we are introducing Teleprompter.",
            wordCount: 142,
            duration: "1:02",
            wpm: 145
        )
    }

    func getSnapshot(in context: Context, completion: @escaping (TeleprompterWidgetEntry) -> Void) {
        completion(placeholder(in: context))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<TeleprompterWidgetEntry>) -> Void) {
        let entry = placeholder(in: context)
        completion(Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(1800))))
    }
}

// 1. Pinned Script Quick Launcher Widget (Small 2x2 & Medium 4x2)
struct QuickLaunchWidgetView: View {
    var entry: TeleprompterWidgetEntry
    private let orange = Color(red: 1.0, green: 0.42, blue: 0.0)

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "viewfinder.circle.fill")
                    .foregroundColor(orange)
                Text("TELEPROMPTER")
                    .font(.system(size: 10, weight: .heavy))
                    .foregroundColor(orange)
                Spacer()
                Text("\(entry.wpm) WPM")
                    .font(.caption2.weight(.bold))
                    .foregroundColor(.white.opacity(0.65))
            }
            Text(entry.scriptTitle)
                .font(.headline.weight(.bold))
                .foregroundColor(.white)
                .lineLimit(2)
            Spacer()
            HStack {
                Label("\(entry.wordCount)w", systemImage: "text.alignleft")
                Spacer()
                Label(entry.duration, systemImage: "clock")
            }
            .font(.caption2.weight(.semibold))
            .foregroundColor(.white.opacity(0.7))
        }
        .padding(14)
        .background(Color(red: 0.05, green: 0.05, blue: 0.07))
    }
}

// 2. Dual Camera & Mirror Rig Widget (Small 2x2 & Medium 4x2)
struct CameraRigWidgetView: View {
    var entry: TeleprompterWidgetEntry
    private let orange = Color(red: 1.0, green: 0.42, blue: 0.0)

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "camera.aperture")
                    .foregroundColor(orange)
                Text("CAMERA STUDIO")
                    .font(.system(size: 10, weight: .heavy))
                    .foregroundColor(orange)
                Spacer()
                Text("4K 60")
                    .font(.caption2.weight(.bold))
                    .foregroundColor(.white.opacity(0.65))
            }
            Text("Front & Back Lens Overlay")
                .font(.subheadline.weight(.bold))
                .foregroundColor(.white)
            Spacer()
            HStack(spacing: 6) {
                Text("Front")
                    .font(.caption2.weight(.bold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(orange)
                    .foregroundColor(.white)
                    .clipShape(Capsule())
                Text("Back")
                    .font(.caption2.weight(.bold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.white.opacity(0.14))
                    .foregroundColor(.white)
                    .clipShape(Capsule())
                Text("Mirror X")
                    .font(.caption2.weight(.bold))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.white.opacity(0.14))
                    .foregroundColor(.white)
                    .clipShape(Capsule())
            }
        }
        .padding(14)
        .background(Color(red: 0.05, green: 0.05, blue: 0.07))
    }
}

// 3. Speaking Pace & Goal Rings Widget (Small 2x2 & Medium 4x2)
struct PaceRingsWidgetView: View {
    var entry: TeleprompterWidgetEntry
    private let orange = Color(red: 1.0, green: 0.42, blue: 0.0)

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Image(systemName: "waveform.path.ecg")
                    .foregroundColor(orange)
                Text("PACE GOAL")
                    .font(.system(size: 10, weight: .heavy))
                    .foregroundColor(orange)
                Spacer()
            }
            HStack(spacing: 10) {
                ZStack {
                    Circle().stroke(Color.white.opacity(0.15), lineWidth: 5).frame(width: 44, height: 44)
                    Circle().trim(from: 0, to: 0.78).stroke(orange, style: StrokeStyle(lineWidth: 5, lineCap: .round)).frame(width: 44, height: 44).rotationEffect(.degrees(-90))
                    Text("\(entry.wpm)")
                        .font(.system(size: 11, weight: .heavy, design: .rounded))
                        .foregroundColor(.white)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("\(entry.wpm) WPM")
                        .font(.caption.weight(.bold))
                        .foregroundColor(.white)
                    Text("Target Pace")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.65))
                }
            }
            Spacer()
            Text("Ready to Record")
                .font(.caption2.weight(.bold))
                .foregroundColor(orange)
        }
        .padding(14)
        .background(Color(red: 0.05, green: 0.05, blue: 0.07))
    }
}

// 4. Large Live Script Reader Widget (Large 4x4)
struct LiveReaderWidgetView: View {
    var entry: TeleprompterWidgetEntry
    private let orange = Color(red: 1.0, green: 0.42, blue: 0.0)

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(systemName: "text.viewfinder")
                    .foregroundColor(orange)
                Text(entry.scriptTitle)
                    .font(.subheadline.weight(.bold))
                    .foregroundColor(.white)
                Spacer()
                Text("\(entry.wpm) WPM")
                    .font(.caption2.weight(.bold))
                    .foregroundColor(orange)
            }
            Text(entry.scriptExcerpt)
                .font(.system(size: 14, weight: .semibold))
                .foregroundColor(.white.opacity(0.9))
                .lineSpacing(4)
            Spacer()
            HStack {
                Text("\(entry.wordCount) words • \(entry.duration)")
                    .font(.caption2)
                    .foregroundColor(.white.opacity(0.6))
                Spacer()
                Text("Tap to Prompt ▶")
                    .font(.caption.weight(.bold))
                    .foregroundColor(orange)
            }
        }
        .padding(16)
        .background(Color(red: 0.05, green: 0.05, blue: 0.07))
    }
}

struct TeleprompterQuickLaunchWidget: Widget {
    let kind: String = "TeleprompterQuickLaunchWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TeleprompterWidgetProvider()) { entry in
            QuickLaunchWidgetView(entry: entry)
        }
        .configurationDisplayName("Quick Script Launcher")
        .description("Launch your pinned script with word count and reading time.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryRectangular])
    }
}

struct TeleprompterCameraRigWidget: Widget {
    let kind: String = "TeleprompterCameraRigWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TeleprompterWidgetProvider()) { entry in
            CameraRigWidgetView(entry: entry)
        }
        .configurationDisplayName("Camera & Mirror Rig")
        .description("Jump straight into Front Camera, Back Camera, or Mirror Glass mode.")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

struct TeleprompterPaceRingsWidget: Widget {
    let kind: String = "TeleprompterPaceRingsWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TeleprompterWidgetProvider()) { entry in
            PaceRingsWidgetView(entry: entry)
        }
        .configurationDisplayName("Speaking Pace & Goal Rings")
        .description("Track your target WPM speaking speed and daily studio goal.")
        .supportedFamilies([.systemSmall, .systemMedium, .accessoryCircular])
    }
}

struct TeleprompterLiveReaderWidget: Widget {
    let kind: String = "TeleprompterLiveReaderWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: TeleprompterWidgetProvider()) { entry in
            LiveReaderWidgetView(entry: entry)
        }
        .configurationDisplayName("Live Script Reader")
        .description("Read your script preview and launch Teleprompter from your Home Screen.")
        .supportedFamilies([.systemLarge])
    }
}

@main
struct TeleprompterWidgetBundle: WidgetBundle {
    var body: some Widget {
        TeleprompterQuickLaunchWidget()
        TeleprompterCameraRigWidget()
        TeleprompterPaceRingsWidget()
        TeleprompterLiveReaderWidget()
    }
}
