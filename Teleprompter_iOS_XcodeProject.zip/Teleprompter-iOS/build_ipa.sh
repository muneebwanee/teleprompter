#!/usr/bin/env bash
set -euo pipefail

echo "Building unsigned Teleprompter.app (v0.0.1)..."
xcodebuild build \
  -project Teleprompter.xcodeproj \
  -scheme Teleprompter \
  -configuration Release \
  -sdk iphoneos \
  -derivedDataPath build_output \
  CODE_SIGN_IDENTITY="" \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGNING_ALLOWED=NO

rm -rf Payload Teleprompter-iOS-Universal.ipa
mkdir -p Payload
cp -R build_output/Build/Products/Release-iphoneos/Teleprompter.app Payload/
zip -r9 Teleprompter-iOS-Universal.ipa Payload
echo "Done: Teleprompter-iOS-Universal.ipa"
