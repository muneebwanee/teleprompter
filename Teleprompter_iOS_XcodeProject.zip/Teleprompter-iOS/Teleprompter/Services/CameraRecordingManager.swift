import Foundation
import AVFoundation
import Photos
import SwiftUI
import UIKit

struct RecordedClip: Identifiable, Equatable {
    let id = UUID()
    var url: URL
    var createdAt: Date
    var durationSeconds: Double
    var title: String
}

final class CameraRecordingManager: NSObject, ObservableObject, AVCaptureFileOutputRecordingDelegate {
    let session = AVCaptureSession()
    @Published var isRecording = false
    @Published var isConfigured = false
    @Published var isSessionRunning = false
    @Published var statusMessage: String?
    @Published var usingFrontCamera = true
    @Published var zoomFactor: CGFloat = 1.0
    @Published var recordedClips: [RecordedClip] = []
    @Published var activeClipForEditor: RecordedClip?
    @Published var showPostCaptureEditor: Bool = false

    private let movieOutput = AVCaptureMovieFileOutput()
    private let sessionQueue = DispatchQueue(label: "com.muneebwanee.teleprompter.cameraQueue")
    private var currentVideoDevice: AVCaptureDevice?

    func configureIfNeeded() {
        let status = AVCaptureDevice.authorizationStatus(for: .video)
        switch status {
        case .authorized:
            startOrResumeSession()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { [weak self] granted in
                guard granted, let self = self else {
                    DispatchQueue.main.async {
                        self?.statusMessage = "Camera access is turned off in Settings."
                    }
                    return
                }
                AVCaptureDevice.requestAccess(for: .audio) { _ in
                    self.startOrResumeSession()
                }
            }
        default:
            DispatchQueue.main.async {
                self.statusMessage = "Enable Camera access in iOS Settings to see live video."
            }
        }
    }

    private func startOrResumeSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if !self.isConfigured {
                self.setupSession(front: self.usingFrontCamera)
            } else if !self.session.isRunning {
                self.session.startRunning()
                DispatchQueue.main.async {
                    self.isSessionRunning = self.session.isRunning
                }
            }
        }
    }

    private func setupSession(front: Bool) {
        if let audioSession = try? AVAudioSession.sharedInstance() {
            try? audioSession.setCategory(.playAndRecord, mode: .videoRecording, options: [.defaultToSpeaker, .allowBluetooth, .mixWithOthers])
            try? audioSession.setActive(true)
        }

        session.beginConfiguration()
        if session.canSetSessionPreset(.high) {
            session.sessionPreset = .high
        }

        session.inputs.forEach { session.removeInput($0) }

        let position: AVCaptureDevice.Position = front ? .front : .back
        let discovery = AVCaptureDevice.DiscoverySession(
            deviceTypes: [.builtInWideAngleCamera, .builtInUltraWideCamera, .builtInTelephotoCamera],
            mediaType: .video,
            position: position
        )

        if let videoDevice = discovery.devices.first ?? AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: position),
           let videoInput = try? AVCaptureDeviceInput(device: videoDevice),
           session.canAddInput(videoInput) {
            session.addInput(videoInput)
            currentVideoDevice = videoDevice
        }

        if AVCaptureDevice.authorizationStatus(for: .audio) == .authorized,
           let audioDevice = AVCaptureDevice.default(for: .audio),
           let audioInput = try? AVCaptureDeviceInput(device: audioDevice),
           session.canAddInput(audioInput) {
            session.addInput(audioInput)
        }

        if !session.outputs.contains(movieOutput) && session.canAddOutput(movieOutput) {
            session.addOutput(movieOutput)
        }

        if let connection = movieOutput.connection(with: .video) {
            if connection.isVideoStabilizationSupported {
                connection.preferredVideoStabilizationMode = .auto
            }
            if connection.isVideoMirroringSupported {
                connection.isVideoMirrored = front
            }
        }

        session.commitConfiguration()
        if !session.isRunning {
            session.startRunning()
        }

        DispatchQueue.main.async {
            self.isConfigured = true
            self.usingFrontCamera = front
            self.isSessionRunning = self.session.isRunning
            self.zoomFactor = 1.0
        }
    }

    func setCamera(front: Bool) {
        guard usingFrontCamera != front || !isConfigured else { return }
        sessionQueue.async { [weak self] in
            self?.setupSession(front: front)
        }
    }

    func flipCamera() {
        let nextPosition = !usingFrontCamera
        sessionQueue.async { [weak self] in
            self?.setupSession(front: nextPosition)
        }
    }

    func setZoom(_ factor: CGFloat) {
        sessionQueue.async { [weak self] in
            guard let self = self, let device = self.currentVideoDevice else { return }
            do {
                try device.lockForConfiguration()
                let clamped = max(1.0, min(factor, min(device.activeFormat.videoMaxZoomFactor, 5.0)))
                device.videoZoomFactor = clamped
                device.unlockForConfiguration()
                DispatchQueue.main.async {
                    self.zoomFactor = clamped
                }
            } catch {}
        }
    }

    func toggleRecording() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if !self.session.isRunning {
                self.session.startRunning()
            }
            if self.movieOutput.isRecording {
                self.movieOutput.stopRecording()
                DispatchQueue.main.async { self.isRecording = false }
            } else {
                if let connection = self.movieOutput.connection(with: .video) {
                    if connection.isVideoMirroringSupported {
                        connection.isVideoMirrored = self.usingFrontCamera
                    }
                }
                let filename = "Teleprompter_Take_\(Int(Date().timeIntervalSince1970)).mov"
                let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
                try? FileManager.default.removeItem(at: tempURL)
                self.movieOutput.startRecording(to: tempURL, recordingDelegate: self)
                DispatchQueue.main.async {
                    self.isRecording = true
                    self.statusMessage = "Recording live video..."
                }
            }
        }
    }

    func stopSession() {
        sessionQueue.async { [weak self] in
            guard let self = self else { return }
            if self.movieOutput.isRecording {
                self.movieOutput.stopRecording()
            }
            if self.session.isRunning {
                self.session.stopRunning()
            }
            DispatchQueue.main.async {
                self.isRecording = false
                self.isSessionRunning = false
            }
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput,
                    didFinishRecordingTo outputFileURL: URL,
                    from connections: [AVCaptureConnection],
                    error: Error?) {
        if let error = error {
            let nsErr = error as NSError
            let successStill = (nsErr.userInfo[AVErrorRecordingSuccessfullyFinishedKey] as? Bool) ?? false
            if !successStill {
                DispatchQueue.main.async {
                    self.isRecording = false
                    self.statusMessage = "Recording stopped: \(error.localizedDescription)"
                }
                return
            }
        }

        let asset = AVURLAsset(url: outputFileURL)
        let duration = max(0.5, CMTimeGetSeconds(asset.duration))
        let clip = RecordedClip(
            url: outputFileURL,
            createdAt: Date(),
            durationSeconds: duration.isFinite ? duration : 1.0,
            title: "Take #\(recordedClips.count + 1)"
        )

        DispatchQueue.main.async {
            self.isRecording = false
            self.recordedClips.insert(clip, at: 0)
            self.activeClipForEditor = clip
            self.showPostCaptureEditor = true
            self.statusMessage = "Take captured! Opening Video Editor..."
        }
    }

    func saveVideoToPhotos(url: URL, completion: @escaping (Bool, String) -> Void) {
        PHPhotoLibrary.requestAuthorization { status in
            guard status == .authorized || status == .limited else {
                DispatchQueue.main.async {
                    completion(false, "Please allow Photos access in Settings to save videos.")
                }
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: url)
            }) { saved, err in
                DispatchQueue.main.async {
                    if saved {
                        completion(true, "Saved to Photos!")
                    } else {
                        completion(false, err?.localizedDescription ?? "Could not save to Photos.")
                    }
                }
            }
        }
    }

    func trimVideo(sourceURL: URL, startTime: Double, endTime: Double, completion: @escaping (Result<RecordedClip, Error>) -> Void) {
        let asset = AVURLAsset(url: sourceURL)
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else {
            completion(.failure(NSError(domain: "Teleprompter", code: -1, userInfo: [NSLocalizedDescriptionKey: "Unable to create video exporter"])))
            return
        }

        let outName = "Teleprompter_Trimmed_\(Int(Date().timeIntervalSince1970)).mov"
        let outURL = FileManager.default.temporaryDirectory.appendingPathComponent(outName)
        try? FileManager.default.removeItem(at: outURL)

        let startCM = CMTime(seconds: max(0, startTime), preferredTimescale: 600)
        let endCM = CMTime(seconds: max(startTime + 0.3, endTime), preferredTimescale: 600)
        exportSession.outputURL = outURL
        exportSession.outputFileType = .mov
        exportSession.timeRange = CMTimeRange(start: startCM, end: endCM)

        exportSession.exportAsynchronously {
            DispatchQueue.main.async {
                switch exportSession.status {
                case .completed:
                    let trimmedDuration = max(0.3, endTime - startTime)
                    let newClip = RecordedClip(
                        url: outURL,
                        createdAt: Date(),
                        durationSeconds: trimmedDuration,
                        title: "Trimmed Clip (\(String(format: "%.1fs", trimmedDuration)))"
                    )
                    self.recordedClips.insert(newClip, at: 0)
                    self.activeClipForEditor = newClip
                    completion(.success(newClip))
                default:
                    let err = exportSession.error ?? NSError(domain: "Teleprompter", code: -2, userInfo: [NSLocalizedDescriptionKey: "Trim failed"])
                    completion(.failure(err))
                }
            }
        }
    }
}

// UIView subclass backed directly by AVCaptureVideoPreviewLayer so live camera feed ALWAYS fills bounds immediately
final class PreviewVideoView: UIView {
    override class var layerClass: AnyClass {
        AVCaptureVideoPreviewLayer.self
    }

    var videoPreviewLayer: AVCaptureVideoPreviewLayer {
        layer as! AVCaptureVideoPreviewLayer
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        videoPreviewLayer.videoGravity = .resizeAspectFill
        updateOrientation()
    }

    func updateOrientation() {
        guard let connection = videoPreviewLayer.connection else { return }
        if connection.isVideoOrientationSupported,
           let windowScene = window?.windowScene {
            switch windowScene.interfaceOrientation {
            case .portrait: connection.videoOrientation = .portrait
            case .landscapeLeft: connection.videoOrientation = .landscapeLeft
            case .landscapeRight: connection.videoOrientation = .landscapeRight
            case .portraitUpsideDown: connection.videoOrientation = .portraitUpsideDown
            default: connection.videoOrientation = .portrait
            }
        }
    }
}

struct CameraPreviewRepresentable: UIViewRepresentable {
    let session: AVCaptureSession

    func makeUIView(context: Context) -> PreviewVideoView {
        let view = PreviewVideoView()
        view.backgroundColor = .black
        view.videoPreviewLayer.session = session
        view.videoPreviewLayer.videoGravity = .resizeAspectFill
        return view
    }

    func updateUIView(_ uiView: PreviewVideoView, context: Context) {
        if uiView.videoPreviewLayer.session !== session {
            uiView.videoPreviewLayer.session = session
        }
        uiView.updateOrientation()
    }
}
