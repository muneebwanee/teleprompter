import SwiftUI

struct ScriptEditorView: View {
    @Binding var script: ScriptItem
    @EnvironmentObject var settings: TeleprompterSettings
    @EnvironmentObject var cameraManager: CameraRecordingManager
    @StateObject private var voiceEngine = VoiceTrackEngine()

    var onStartPrompter: () -> Void
    var onOpenCameraStudio: () -> Void
    var onOpenSettings: () -> Void

    private let categories = ["Keynote", "Video", "Update", "Podcast"]

    var body: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint

        VStack(spacing: 14) {
            // Top Floating Liquid Glass Header
            VStack(spacing: 12) {
                HStack(spacing: 12) {
                    TextField("Script Title", text: $script.title)
                        .font(.title2.weight(.bold))
                        .foregroundColor(settings.theme.primaryText(isLight: isLight))
                        .textFieldStyle(.plain)

                    Picker("Category", selection: $script.category) {
                        ForEach(categories, id: \.self) { cat in
                            Text(cat).tag(cat)
                        }
                    }
                    .pickerStyle(.menu)
                    .tint(accent)

                    Button {
                        withAnimation(.spring()) {
                            script.isPinned.toggle()
                        }
                    } label: {
                        Image(systemName: script.isPinned ? "pin.fill" : "pin")
                            .foregroundColor(script.isPinned ? accent : settings.theme.secondaryText(isLight: isLight))
                    }
                    .buttonStyle(.bordered)
                }

                // Action Bar: Metrics + Listen Aloud + Short Lines + Camera + Start Reading
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 10) {
                        metricPill(icon: "text.alignleft", label: "\(script.wordCount) words")
                        metricPill(icon: "timer", label: "Time \(script.formattedDuration)")

                        HStack(spacing: 6) {
                            Image(systemName: "speedometer")
                                .font(.caption)
                                .foregroundColor(accent)
                            Text("\(script.targetWPM) WPM")
                                .font(.caption.weight(.bold))
                                .foregroundColor(settings.theme.primaryText(isLight: isLight))
                            Stepper("", value: $script.targetWPM, in: 60...260, step: 5)
                                .labelsHidden()
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(Color.primary.opacity(0.06))
                        .clipShape(Capsule())

                        Button {
                            voiceEngine.toggleListenAloud(text: script.content)
                        } label: {
                            Label(voiceEngine.isSpeakingAloud ? "Stop Voice" : "Listen", systemImage: voiceEngine.isSpeakingAloud ? "stop.circle.fill" : "speaker.wave.2.fill")
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(voiceEngine.isSpeakingAloud ? Color.red.opacity(0.22) : accent.opacity(0.16))
                                .foregroundColor(voiceEngine.isSpeakingAloud ? .red : accent)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)

                        Button {
                            withAnimation(.spring()) {
                                script.formatShortLines()
                            }
                        } label: {
                            Label("Short Lines", systemImage: "text.line.first.and.arrowtriangle.forward")
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(accent.opacity(0.16))
                                .foregroundColor(accent)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)

                        Button {
                            onOpenCameraStudio()
                        } label: {
                            Label("Camera", systemImage: "video.fill")
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(Color.primary.opacity(0.08))
                                .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)

                        Button {
                            onOpenSettings()
                        } label: {
                            Label("Settings", systemImage: "slider.horizontal.3")
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(Color.primary.opacity(0.08))
                                .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)

                        Button {
                            onStartPrompter()
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: "play.fill")
                                Text("Start Reading")
                                    .fontWeight(.bold)
                            }
                            .font(.subheadline)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 9)
                            .background(settings.theme.accentGradient)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                            .shadow(color: accent.opacity(0.42), radius: 10, x: 0, y: 5)
                        }
                        .buttonStyle(.plain)
                    }
                }

                // Cue Ribbon
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        Text("ADD CUE")
                            .font(.system(size: 10, weight: .heavy))
                            .foregroundColor(settings.theme.secondaryText(isLight: isLight))

                        cueInsertButton("[PAUSE]", icon: "pause.circle.fill")
                        cueInsertButton("[EMPHASIS]", icon: "bolt.fill")
                        cueInsertButton("[SLOW]", icon: "tortoise.fill")
                        cueInsertButton("[FAST]", icon: "hare.fill")
                        cueInsertButton("[LOOK AT LENS]", icon: "eye.fill")
                    }
                }
            }
            .padding(16)
            .liquidGlass(cornerRadius: 24)

            // Main Glass Script Editor Card
            TextEditor(text: $script.content)
                .font(.system(size: 20, weight: .regular, design: settings.fontDesign.swiftUIFontDesign))
                .foregroundColor(settings.theme.primaryText(isLight: isLight))
                .lineSpacing(9)
                .padding(18)
                .scrollContentBackground(.hidden)
                .liquidGlass(cornerRadius: 24)
        }
        .padding(14)
        .background(settings.theme.backgroundColor(isLight: isLight))
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear {
            voiceEngine.stop()
        }
    }

    private func metricPill(icon: String, label: String) -> some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint
        return HStack(spacing: 6) {
            Image(systemName: icon)
                .font(.caption)
                .foregroundColor(accent)
            Text(label)
                .font(.caption.weight(.bold))
                .foregroundColor(settings.theme.primaryText(isLight: isLight))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
        .background(Color.primary.opacity(0.06))
        .clipShape(Capsule())
    }

    private func cueInsertButton(_ tag: String, icon: String) -> some View {
        let accent = settings.theme.accentTint
        return Button {
            script.content += "\n\(tag)\n"
            script.lastModified = Date()
        } label: {
            Label(tag, systemImage: icon)
                .font(.caption.weight(.bold))
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(accent.opacity(0.16))
                .foregroundColor(accent)
                .overlay(
                    Capsule()
                        .stroke(accent.opacity(0.38), lineWidth: 1)
                )
                .clipShape(Capsule())
        }
        .buttonStyle(.plain)
    }
}
