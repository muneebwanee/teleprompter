import SwiftUI

struct TeleprompterView: View {
    let script: ScriptItem
    @EnvironmentObject var settings: TeleprompterSettings
    @EnvironmentObject var cameraManager: CameraRecordingManager
    @Environment(\.dismiss) private var dismiss

    @StateObject private var voiceEngine = VoiceTrackEngine()

    @State private var isPlaying: Bool = false
    @State private var countdownRemaining: Int = 0
    @State private var scrollOffset: CGFloat = 0.0
    @State private var activeParagraphIndex: Int = 0
    @State private var elapsedSeconds: Int = 0
    @State private var showControlsHUD: Bool = true

    private let frameTimer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()
    private let secondTimer = Timer.publish(every: 1.0, on: .main, in: .common).autoconnect()

    var paragraphs: [String] {
        script.paragraphs
    }

    var body: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint

        GeometryReader { geo in
            ZStack {
                // 1. Background or Full-Screen Live Camera Backdrop
                if settings.showCameraPreview && settings.fullScreenCameraStage {
                    CameraPreviewRepresentable(session: cameraManager.session)
                        .ignoresSafeArea()
                    Color.black.opacity(0.48)
                        .ignoresSafeArea()
                } else {
                    settings.theme.backgroundColor(isLight: isLight)
                        .ignoresSafeArea()
                }

                // 2. Main Scrolling Script Canvas (Tap gestures attached ONLY here so HUD buttons never vanish on tap)
                ScrollViewReader { proxy in
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack(alignment: .leading, spacing: settings.lineSpacing + 14) {
                            Spacer()
                                .frame(height: geo.size.height * settings.eyeLineVerticalRatio)

                            ForEach(Array(paragraphs.enumerated()), id: \.offset) { index, line in
                                paragraphRow(index: index, text: line)
                                    .id(index)
                                    .onTapGesture {
                                        withAnimation(.easeInOut(duration: 0.25)) {
                                            activeParagraphIndex = index
                                            proxy.scrollTo(index, anchor: UnitPoint(x: 0.5, y: settings.eyeLineVerticalRatio))
                                        }
                                    }
                            }

                            Spacer()
                                .frame(height: geo.size.height * 0.72)
                        }
                        .padding(.horizontal, settings.horizontalMargin)
                        .offset(y: (settings.scrollMode == .continuous || settings.scrollMode == .voiceLevel) ? -scrollOffset : 0)
                    }
                    .contentShape(Rectangle())
                    .onTapGesture(count: 2) {
                        togglePlayPause()
                    }
                    .onTapGesture(count: 1) {
                        withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) {
                            showControlsHUD.toggle()
                        }
                    }
                    .scaleEffect(
                        x: settings.mirrorHorizontal ? -1.0 : 1.0,
                        y: settings.mirrorVertical ? -1.0 : 1.0
                    )
                    .onChange(of: voiceEngine.matchedParagraphIndex) { newIdx in
                        guard settings.scrollMode == .voiceActivated else { return }
                        withAnimation(.easeInOut(duration: 0.35)) {
                            activeParagraphIndex = newIdx
                            proxy.scrollTo(newIdx, anchor: UnitPoint(x: 0.5, y: settings.eyeLineVerticalRatio))
                        }
                    }
                }

                // 3. Eye-Line Reading Guide Band
                if settings.showEyeLineGuide {
                    eyeLineOverlay(in: geo)
                }

                // 4. Top Studio Bar & Bottom Control Deck (Isolated from stage tap gesture)
                VStack {
                    topStudioBar
                    Spacer()
                    if showControlsHUD {
                        bottomControlDeck
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(14)

                // 5. Countdown Overlay
                if countdownRemaining > 0 {
                    ZStack {
                        Color.black.opacity(0.74).ignoresSafeArea()
                        VStack(spacing: 12) {
                            Text("\(countdownRemaining)")
                                .font(.system(size: 110, weight: .bold, design: .rounded))
                                .foregroundColor(accent)
                            Text("Keep your eyes near the camera lens")
                                .font(.headline)
                                .foregroundColor(.white.opacity(0.85))
                        }
                    }
                }
            }
        }
        .statusBar(hidden: true)
        .onAppear {
            UIApplication.shared.isIdleTimerDisabled = true
            settings.wordsPerMinute = Double(script.targetWPM)
            if settings.showCameraPreview {
                cameraManager.configureIfNeeded()
            }
        }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
            voiceEngine.stop()
        }
        .onReceive(frameTimer) { _ in
            guard isPlaying && countdownRemaining == 0 else { return }
            let pixelsPerSecond = CGFloat(settings.wordsPerMinute) * CGFloat(settings.fontSize) * 0.0145
            if settings.scrollMode == .continuous {
                scrollOffset += pixelsPerSecond / 60.0
            } else if settings.scrollMode == .voiceLevel && voiceEngine.isSpeakingNow {
                scrollOffset += (pixelsPerSecond * 1.15) / 60.0
            }
        }
        .onReceive(secondTimer) { _ in
            if countdownRemaining > 0 {
                countdownRemaining -= 1
                if countdownRemaining == 0 {
                    startActiveScrolling()
                }
            } else if isPlaying {
                elapsedSeconds += 1
            }
        }
        .sheet(isPresented: $cameraManager.showPostCaptureEditor) {
            VideoClipEditorView()
                .environmentObject(cameraManager)
                .environmentObject(settings)
        }
    }

    @ViewBuilder
    private func paragraphRow(index: Int, text: String) -> some View {
        let isLight = settings.isLightMode && !(settings.showCameraPreview && settings.fullScreenCameraStage)
        let accent = settings.theme.accentTint
        let isCueOnly = text.hasPrefix("[") && text.hasSuffix("]")
        let isFocused = !settings.focusDimmingEnabled || abs(index - activeParagraphIndex) <= 1 || settings.scrollMode == .continuous

        if isCueOnly && settings.renderCueBadges {
            HStack(spacing: 8) {
                Image(systemName: "waveform.badge.mic")
                Text(text.replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: ""))
                    .font(.system(size: max(16, settings.fontSize * 0.45), weight: .bold, design: .rounded))
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 6)
            .background(accent.opacity(0.24))
            .foregroundColor(accent)
            .clipShape(Capsule())
        } else {
            Text(cleanDisplayLine(text))
                .font(.system(
                    size: settings.fontSize,
                    weight: (text.contains("[EMPHASIS]") || settings.easyReadEnabled) ? .bold : .semibold,
                    design: settings.fontDesign.swiftUIFontDesign
                ))
                .foregroundColor(
                    text.contains("[EMPHASIS]")
                        ? accent
                        : settings.theme.primaryText(isLight: isLight).opacity(isFocused ? 1.0 : 0.35)
                )
                .lineSpacing(settings.lineSpacing)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private func cleanDisplayLine(_ raw: String) -> String {
        raw.replacingOccurrences(of: "[EMPHASIS]", with: "")
           .trimmingCharacters(in: .whitespaces)
    }

    private func eyeLineOverlay(in geo: GeometryProxy) -> some View {
        let accent = settings.theme.accentTint
        let yPos = geo.size.height * settings.eyeLineVerticalRatio
        return ZStack {
            Rectangle()
                .fill(accent.opacity(0.10))
                .frame(height: settings.fontSize * 2.1)
                .overlay(
                    HStack {
                        Image(systemName: "arrowtriangle.right.fill")
                            .foregroundColor(accent)
                            .padding(.leading, 8)
                        Spacer()
                        Image(systemName: "arrowtriangle.left.fill")
                            .foregroundColor(accent)
                            .padding(.trailing, 8)
                    }
                )
                .position(x: geo.size.width / 2, y: yPos)
        }
        .allowsHitTesting(false)
    }

    private var topStudioBar: some View {
        let accent = settings.theme.accentTint
        return HStack(spacing: 10) {
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.title2)
                    .foregroundColor(.white.opacity(0.9))
            }

            if settings.showElapsedTimer {
                HStack(spacing: 6) {
                    Circle()
                        .fill(cameraManager.isRecording ? Color.red : (isPlaying ? accent : Color.gray))
                        .frame(width: 8, height: 8)
                    Text(String(format: "%02d:%02d", elapsedSeconds / 60, elapsedSeconds % 60))
                        .font(.system(.subheadline, design: .monospaced).weight(.semibold))
                        .foregroundColor(.white)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(.ultraThinMaterial)
                .clipShape(Capsule())
            }

            // Front / Back Camera & Backdrop Quick Controls
            if settings.showCameraPreview {
                HStack(spacing: 6) {
                    Button {
                        cameraManager.setCamera(front: true)
                    } label: {
                        Text("Front")
                            .font(.caption2.weight(.bold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(cameraManager.usingFrontCamera ? accent : Color.black.opacity(0.45))
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                    }

                    Button {
                        cameraManager.setCamera(front: false)
                    } label: {
                        Text("Back")
                            .font(.caption2.weight(.bold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(!cameraManager.usingFrontCamera ? accent : Color.black.opacity(0.45))
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                    }

                    Button {
                        withAnimation(.spring()) {
                            settings.fullScreenCameraStage.toggle()
                        }
                    } label: {
                        Text(settings.fullScreenCameraStage ? "Small Cam" : "Full Cam")
                            .font(.caption2.weight(.bold))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(Color.black.opacity(0.45))
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                    }
                }
            }

            Spacer()

            // Post-Capture Clips / Video Trimmer Button
            Button {
                cameraManager.showPostCaptureEditor = true
            } label: {
                HStack(spacing: 4) {
                    Image(systemName: "scissors")
                    Text("Edit Video")
                        .font(.caption2.weight(.bold))
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(.ultraThinMaterial)
                .foregroundColor(.white)
                .clipShape(Capsule())
            }

            // Live Camera Picture-in-Picture Box + Record Button
            if settings.showCameraPreview && !settings.fullScreenCameraStage {
                ZStack(alignment: .bottomTrailing) {
                    CameraPreviewRepresentable(session: cameraManager.session)
                        .frame(width: 136, height: 88)
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(cameraManager.isRecording ? Color.red : accent.opacity(0.8), lineWidth: 2)
                        )

                    Button {
                        cameraManager.toggleRecording()
                    } label: {
                        Image(systemName: cameraManager.isRecording ? "stop.circle.fill" : "record.circle.fill")
                            .font(.title3)
                            .foregroundColor(cameraManager.isRecording ? .red : .white)
                            .padding(5)
                            .background(Color.black.opacity(0.5))
                            .clipShape(Circle())
                            .padding(4)
                    }
                }
            } else if settings.showCameraPreview && settings.fullScreenCameraStage {
                Button {
                    cameraManager.toggleRecording()
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: cameraManager.isRecording ? "stop.circle.fill" : "record.circle.fill")
                        Text(cameraManager.isRecording ? "Stop Rec" : "Record")
                            .font(.caption.weight(.bold))
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(cameraManager.isRecording ? Color.red : accent)
                    .foregroundColor(.white)
                    .clipShape(Capsule())
                }
            }
        }
    }

    private var bottomControlDeck: some View {
        let accent = settings.theme.accentTint
        return VStack(spacing: 12) {
            // Interactive Always-Visible Mode Selector Bar (Never vanishes when tapped!)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(ScrollMode.allCases) { mode in
                        let isSelected = (settings.scrollMode == mode)
                        Button {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.78)) {
                                settings.scrollMode = mode
                                if isPlaying {
                                    configureVoiceIfNeeded()
                                }
                            }
                        } label: {
                            HStack(spacing: 6) {
                                Image(systemName: mode.icon)
                                    .font(.caption)
                                Text(mode.rawValue)
                                    .font(.caption.weight(.bold))
                            }
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(
                                Capsule()
                                    .fill(isSelected ? AnyShapeStyle(settings.theme.accentGradient) : AnyShapeStyle(Color.white.opacity(0.10)))
                            )
                            .foregroundColor(.white)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            // Primary Playback & Mirror Controls
            HStack(spacing: 22) {
                Button {
                    withAnimation(.spring()) {
                        scrollOffset = 0
                        activeParagraphIndex = 0
                        elapsedSeconds = 0
                    }
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "backward.end.fill")
                            .font(.title3)
                        Text("Restart")
                            .font(.caption2)
                    }
                    .foregroundColor(.white)
                }

                Button {
                    togglePlayPause()
                } label: {
                    Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                        .font(.system(size: 54))
                        .foregroundColor(accent)
                        .shadow(color: accent.opacity(0.5), radius: 10)
                }

                Button {
                    withAnimation(.spring()) {
                        settings.mirrorHorizontal.toggle()
                    }
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "arrow.left.and.right.righttriangle.left.righttriangle.right")
                        Text("Flip L-R")
                            .font(.caption2)
                    }
                    .foregroundColor(settings.mirrorHorizontal ? accent : .white)
                }

                Button {
                    withAnimation(.spring()) {
                        settings.mirrorVertical.toggle()
                    }
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: "arrow.up.and.down.righttriangle.up.righttriangle.down")
                        Text("Flip U-D")
                            .font(.caption2)
                    }
                    .foregroundColor(settings.mirrorVertical ? accent : .white)
                }

                Button {
                    withAnimation(.spring()) {
                        settings.showCameraPreview.toggle()
                        if settings.showCameraPreview {
                            cameraManager.configureIfNeeded()
                        }
                    }
                } label: {
                    VStack(spacing: 2) {
                        Image(systemName: settings.showCameraPreview ? "video.fill" : "video.slash.fill")
                        Text("Camera")
                            .font(.caption2)
                    }
                    .foregroundColor(settings.showCameraPreview ? accent : .white)
                }
            }

            // Speed & Font Size Sliders
            HStack(spacing: 16) {
                HStack(spacing: 8) {
                    Image(systemName: "speedometer")
                        .font(.caption)
                        .foregroundColor(accent)
                    Slider(value: $settings.wordsPerMinute, in: 60...260, step: 5)
                        .tint(accent)
                    Text("\(Int(settings.wordsPerMinute)) WPM")
                        .font(.caption.monospacedDigit().weight(.bold))
                        .frame(width: 66, alignment: .trailing)
                }

                HStack(spacing: 8) {
                    Image(systemName: "textformat.size")
                        .font(.caption)
                        .foregroundColor(accent)
                    Slider(value: $settings.fontSize, in: 22...76, step: 2)
                        .tint(accent)
                    Text("\(Int(settings.fontSize))pt")
                        .font(.caption.monospacedDigit().weight(.bold))
                        .frame(width: 42, alignment: .trailing)
                }
            }
            .foregroundColor(.white)
        }
        .padding(16)
        .background(.ultraThinMaterial)
        .background(Color.black.opacity(0.55))
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(accent.opacity(0.35), lineWidth: 1)
        )
    }

    private func togglePlayPause() {
        if isPlaying {
            isPlaying = false
            voiceEngine.stop()
        } else {
            if scrollOffset == 0 && settings.countdownSeconds > 0 {
                countdownRemaining = settings.countdownSeconds
            } else {
                startActiveScrolling()
            }
        }
    }

    private func startActiveScrolling() {
        isPlaying = true
        configureVoiceIfNeeded()
    }

    private func configureVoiceIfNeeded() {
        if settings.scrollMode == .voiceActivated || settings.scrollMode == .voiceLevel {
            voiceEngine.requestPermissionsAndStart(paragraphs: paragraphs)
        } else {
            voiceEngine.stop()
        }
    }
}
