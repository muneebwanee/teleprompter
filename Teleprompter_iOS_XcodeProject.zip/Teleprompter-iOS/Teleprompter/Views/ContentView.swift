import SwiftUI

struct ContentView: View {
    @EnvironmentObject var scriptStore: ScriptStore
    @EnvironmentObject var settings: TeleprompterSettings
    @EnvironmentObject var cameraManager: CameraRecordingManager

    @State private var searchText: String = ""
    @State private var selectedCategory: String = "All"
    @State private var isPresentingPrompter: Bool = false
    @State private var isShowingCameraStudio: Bool = false
    @State private var isShowingSettingsSheet: Bool = false
    @State private var isShowingWidgetsSheet: Bool = false

    private let categories = ["All", "Keynote", "Video", "Update", "Podcast"]

    var filteredScripts: [ScriptItem] {
        scriptStore.scripts.filter { item in
            let matchesCategory = (selectedCategory == "All") || (item.category == selectedCategory)
            let matchesSearch = searchText.isEmpty ||
                item.title.localizedCaseInsensitiveContains(searchText) ||
                item.content.localizedCaseInsensitiveContains(searchText)
            return matchesCategory && matchesSearch
        }
    }

    var body: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint

        ZStack {
            settings.theme.backgroundColor(isLight: isLight)
                .ignoresSafeArea()

            RadialGradient(
                colors: [accent.opacity(isLight ? 0.14 : 0.22), Color.clear],
                center: .topLeading,
                startRadius: 20,
                endRadius: 540
            )
            .ignoresSafeArea()

            NavigationSplitView {
                sidebarList
                    .navigationSplitViewColumnWidth(min: 300, ideal: 330, max: 380)
            } detail: {
                if let script = scriptStore.selectedScript {
                    ScriptEditorView(
                        script: Binding(
                            get: { script },
                            set: { scriptStore.selectedScript = $0 }
                        ),
                        onStartPrompter: { isPresentingPrompter = true },
                        onOpenCameraStudio: { isShowingCameraStudio = true },
                        onOpenSettings: { isShowingSettingsSheet = true }
                    )
                } else {
                    emptyDetailPlaceholder
                }
            }
            .tint(accent)
        }
        .fullScreenCover(isPresented: $isPresentingPrompter) {
            if let script = scriptStore.selectedScript {
                TeleprompterView(script: script)
                    .environmentObject(settings)
                    .environmentObject(cameraManager)
            }
        }
        .fullScreenCover(isPresented: $isShowingCameraStudio) {
            if let script = scriptStore.selectedScript {
                BroadcastCameraView(script: script)
                    .environmentObject(settings)
                    .environmentObject(cameraManager)
            }
        }
        .sheet(isPresented: $isShowingSettingsSheet) {
            SettingsDrawerView()
                .environmentObject(settings)
        }
        .sheet(isPresented: $isShowingWidgetsSheet) {
            WidgetsGalleryView(
                onLaunchPrompter: {
                    isShowingWidgetsSheet = false
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                        isPresentingPrompter = true
                    }
                },
                onOpenCamera: {
                    isShowingWidgetsSheet = false
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                        isShowingCameraStudio = true
                    }
                }
            )
            .environmentObject(scriptStore)
            .environmentObject(settings)
            .environmentObject(cameraManager)
        }
        .sheet(isPresented: $cameraManager.showPostCaptureEditor) {
            VideoClipEditorView()
                .environmentObject(cameraManager)
                .environmentObject(settings)
        }
    }

    private var sidebarList: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint

        return VStack(spacing: 12) {
            // Animated Vector Wave Header Card
            ZStack(alignment: .leading) {
                VectorMotionArtView(speedMultiplier: 1.0)
                    .frame(height: 58)
                    .opacity(0.85)

                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Reading Studio")
                            .font(.caption.weight(.heavy))
                            .foregroundColor(accent)
                        Text("\(scriptStore.scripts.count) Scripts • \(Int(settings.wordsPerMinute)) WPM")
                            .font(.caption2.weight(.semibold))
                            .foregroundColor(settings.theme.secondaryText(isLight: isLight))
                    }
                    Spacer()
                    Button {
                        isShowingCameraStudio = true
                    } label: {
                        Label("Camera", systemImage: "camera.fill")
                            .font(.caption.weight(.bold))
                            .padding(.horizontal, 11)
                            .padding(.vertical, 6)
                            .background(settings.theme.accentGradient)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 14)
            }
            .liquidGlass(cornerRadius: 20, isHighlighted: true)
            .padding(.horizontal, 14)
            .padding(.top, 6)

            // Category Pills
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(categories, id: \.self) { cat in
                        Button {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.78)) {
                                selectedCategory = cat
                            }
                        } label: {
                            Text(cat)
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 13)
                                .padding(.vertical, 7)
                                .background(
                                    Capsule()
                                        .fill(
                                            selectedCategory == cat
                                                ? AnyShapeStyle(settings.theme.accentGradient)
                                                : AnyShapeStyle(Color.primary.opacity(0.08))
                                        )
                                )
                                .foregroundColor(selectedCategory == cat ? .white : settings.theme.secondaryText(isLight: isLight))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
            }

            // Script Cards List
            ScrollView {
                LazyVStack(spacing: 10) {
                    ForEach(filteredScripts) { item in
                        let isSelected = (scriptStore.selectedScriptID == item.id)
                        Button {
                            withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) {
                                scriptStore.selectedScriptID = item.id
                            }
                        } label: {
                            VStack(alignment: .leading, spacing: 7) {
                                HStack {
                                    if item.isPinned {
                                        Image(systemName: "pin.fill")
                                            .font(.caption2)
                                            .foregroundColor(accent)
                                    }
                                    Text(item.title)
                                        .font(.headline.weight(.bold))
                                        .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                        .lineLimit(1)
                                    Spacer()
                                    Text(item.category.uppercased())
                                        .font(.system(size: 10, weight: .heavy))
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 3)
                                        .background(accent.opacity(0.18))
                                        .foregroundColor(accent)
                                        .clipShape(Capsule())
                                }

                                Text(item.content.replacingOccurrences(of: "\n", with: " "))
                                    .font(.subheadline)
                                    .foregroundColor(settings.theme.secondaryText(isLight: isLight))
                                    .lineLimit(2)

                                HStack(spacing: 12) {
                                    Label("\(item.wordCount)w", systemImage: "text.word.spacing")
                                    Label(item.formattedDuration, systemImage: "clock")
                                    Label("\(item.targetWPM) WPM", systemImage: "speedometer")
                                        .foregroundColor(accent)
                                }
                                .font(.caption2.weight(.semibold))
                                .foregroundColor(settings.theme.secondaryText(isLight: isLight))
                            }
                            .padding(14)
                            .liquidGlass(cornerRadius: 20, isHighlighted: isSelected)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 14)
                .padding(.bottom, 16)
            }
        }
        .background(settings.theme.backgroundColor(isLight: isLight))
        .navigationTitle("Teleprompter")
        .searchable(text: $searchText, prompt: "Search scripts or cues...")
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                HStack(spacing: 12) {
                    Button {
                        isShowingSettingsSheet = true
                    } label: {
                        Image(systemName: "slider.horizontal.3")
                            .foregroundColor(accent)
                    }

                    Button {
                        isShowingWidgetsSheet = true
                    } label: {
                        Image(systemName: "square.grid.2x2.fill")
                            .foregroundColor(accent)
                    }

                    Button {
                        cameraManager.showPostCaptureEditor = true
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "film.stack")
                            if !cameraManager.recordedClips.isEmpty {
                                Text("\(cameraManager.recordedClips.count)")
                                    .font(.caption2.weight(.bold))
                            }
                        }
                        .foregroundColor(accent)
                    }
                }
            }
            ToolbarItem(placement: .primaryAction) {
                Button {
                    withAnimation(.spring()) {
                        _ = scriptStore.createScript()
                    }
                } label: {
                    Label("New Script", systemImage: "plus.circle.fill")
                        .foregroundColor(accent)
                }
            }
        }
    }

    private var emptyDetailPlaceholder: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint
        return VStack(spacing: 16) {
            Image(systemName: "text.viewfinder")
                .font(.system(size: 56))
                .foregroundColor(accent)
            Text("Select or Create a Script")
                .font(.title3.weight(.bold))
                .foregroundColor(settings.theme.primaryText(isLight: isLight))
            Button("Create New Script") {
                _ = scriptStore.createScript()
            }
            .buttonStyle(.borderedProminent)
            .tint(accent)
        }
    }
}
