import SwiftUI
import AVKit
import AVFoundation
import UIKit
import UniformTypeIdentifiers

struct ShareSheetView: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

struct DocumentExportPicker: UIViewControllerRepresentable {
    let fileURL: URL
    var onCompletion: (Bool) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forExporting: [fileURL], asCopy: true)
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onCompletion: onCompletion)
    }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onCompletion: (Bool) -> Void
        init(onCompletion: @escaping (Bool) -> Void) {
            self.onCompletion = onCompletion
        }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onCompletion(true)
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCompletion(false)
        }
    }
}

struct VideoClipEditorView: View {
    @EnvironmentObject var cameraManager: CameraRecordingManager
    @EnvironmentObject var settings: TeleprompterSettings
    @Environment(\.dismiss) private var dismiss

    @State private var player: AVPlayer?
    @State private var startTime: Double = 0.0
    @State private var endTime: Double = 10.0
    @State private var totalDuration: Double = 10.0
    @State private var playbackRate: Float = 1.0
    @State private var isMuted: Bool = false
    @State private var isTrimming: Bool = false
    @State private var toastMessage: String?
    @State private var isShowingShareSheet: Bool = false
    @State private var isShowingFilesExporter: Bool = false

    private let rates: [Float] = [0.5, 1.0, 1.25, 1.5, 2.0]

    var currentClip: RecordedClip? {
        cameraManager.activeClipForEditor ?? cameraManager.recordedClips.first
    }

    var body: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint

        NavigationStack {
            ZStack {
                settings.theme.backgroundColor(isLight: isLight)
                    .ignoresSafeArea()

                RadialGradient(
                    colors: [accent.opacity(0.22), Color.clear],
                    center: .topTrailing,
                    startRadius: 20,
                    endRadius: 480
                )
                .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 18) {
                        if let clip = currentClip {
                            // Video Player Card
                            VStack(spacing: 12) {
                                ZStack(alignment: .topLeading) {
                                    if let player = player {
                                        VideoPlayer(player: player)
                                            .frame(height: 300)
                                            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                                    } else {
                                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                                            .fill(Color.black)
                                            .frame(height: 300)
                                            .overlay(ProgressView().tint(accent))
                                    }

                                    HStack(spacing: 8) {
                                        Image(systemName: "film.fill")
                                        Text(clip.title)
                                            .font(.caption.weight(.bold))
                                        Text("• \(String(format: "%.1fs", totalDuration))")
                                            .font(.caption.monospacedDigit())
                                    }
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(.ultraThinMaterial)
                                    .clipShape(Capsule())
                                    .padding(12)
                                }

                                // Playback Speed & Mute Bar
                                HStack(spacing: 10) {
                                    Button {
                                        isMuted.toggle()
                                        player?.isMuted = isMuted
                                    } label: {
                                        Label(isMuted ? "Muted" : "Sound On", systemImage: isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                                            .font(.caption.weight(.bold))
                                            .padding(.horizontal, 12)
                                            .padding(.vertical, 8)
                                            .background(isMuted ? Color.red.opacity(0.22) : accent.opacity(0.18))
                                            .foregroundColor(isMuted ? .red : accent)
                                            .clipShape(Capsule())
                                    }

                                    Spacer()

                                    Text("Speed")
                                        .font(.caption2.weight(.bold))
                                        .foregroundColor(settings.theme.secondaryText(isLight: isLight))

                                    ForEach(rates, id: \.self) { rate in
                                        Button {
                                            playbackRate = rate
                                            player?.playImmediately(atRate: rate)
                                        } label: {
                                            Text("\(String(format: "%g", rate))x")
                                                .font(.caption2.weight(.bold))
                                                .padding(.horizontal, 9)
                                                .padding(.vertical, 6)
                                                .background(playbackRate == rate ? accent : Color.white.opacity(0.08))
                                                .foregroundColor(playbackRate == rate ? .white : settings.theme.primaryText(isLight: isLight))
                                                .clipShape(Capsule())
                                        }
                                    }
                                }
                            }
                            .padding(16)
                            .liquidGlass(cornerRadius: 26, isHighlighted: true)

                            // Trim Video Card
                            VStack(alignment: .leading, spacing: 14) {
                                HStack {
                                    Label("Trim Video Clip", systemImage: "timeline.selection")
                                        .font(.headline.weight(.bold))
                                        .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                    Spacer()
                                    Text("Selected: \(String(format: "%.1fs", max(0.1, endTime - startTime)))")
                                        .font(.caption.weight(.bold).monospacedDigit())
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 5)
                                        .background(accent.opacity(0.18))
                                        .foregroundColor(accent)
                                        .clipShape(Capsule())
                                }

                                // Visual Trim Timeline Bar
                                GeometryReader { geo in
                                    let w = max(1, geo.size.width)
                                    let startFrac = CGFloat(startTime / max(0.1, totalDuration))
                                    let endFrac = CGFloat(endTime / max(0.1, totalDuration))
                                    ZStack(alignment: .leading) {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color.white.opacity(0.08))
                                            .frame(height: 28)

                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(settings.theme.accentGradient)
                                            .frame(width: max(12, (endFrac - startFrac) * w), height: 28)
                                            .offset(x: startFrac * w)
                                    }
                                }
                                .frame(height: 28)

                                VStack(spacing: 10) {
                                    HStack {
                                        Text("Start: \(String(format: "%.1fs", startTime))")
                                            .font(.caption.weight(.semibold).monospacedDigit())
                                            .frame(width: 86, alignment: .leading)
                                        Slider(
                                            value: Binding(
                                                get: { startTime },
                                                set: { newVal in
                                                    startTime = min(newVal, max(0, endTime - 0.3))
                                                    seekPlayer(to: startTime)
                                                }
                                            ),
                                            in: 0...max(0.5, totalDuration)
                                        )
                                        .tint(accent)
                                    }

                                    HStack {
                                        Text("End: \(String(format: "%.1fs", endTime))")
                                            .font(.caption.weight(.semibold).monospacedDigit())
                                            .frame(width: 86, alignment: .leading)
                                        Slider(
                                            value: Binding(
                                                get: { endTime },
                                                set: { newVal in
                                                    endTime = max(newVal, min(totalDuration, startTime + 0.3))
                                                    seekPlayer(to: endTime)
                                                }
                                            ),
                                            in: 0...max(0.5, totalDuration)
                                        )
                                        .tint(accent)
                                    }
                                }
                                .foregroundColor(settings.theme.primaryText(isLight: isLight))

                                HStack(spacing: 12) {
                                    Button {
                                        seekPlayer(to: startTime)
                                        player?.playImmediately(atRate: playbackRate)
                                    } label: {
                                        Label("Preview Trim", systemImage: "play.fill")
                                            .font(.subheadline.weight(.bold))
                                            .frame(maxWidth: .infinity)
                                            .padding(.vertical, 12)
                                            .background(Color.white.opacity(0.10))
                                            .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    }

                                    Button {
                                        guard !isTrimming else { return }
                                        isTrimming = true
                                        cameraManager.trimVideo(sourceURL: clip.url, startTime: startTime, endTime: endTime) { result in
                                            isTrimming = false
                                            switch result {
                                            case .success(let newClip):
                                                loadClip(newClip)
                                                showToast("Trimmed to \(String(format: "%.1fs", newClip.durationSeconds))!")
                                            case .failure(let err):
                                                showToast("Trim error: \(err.localizedDescription)")
                                            }
                                        }
                                    } label: {
                                        HStack(spacing: 8) {
                                            if isTrimming {
                                                ProgressView().tint(.white)
                                            } else {
                                                Image(systemName: "scissors")
                                            }
                                            Text(isTrimming ? "Trimming..." : "Apply Trim")
                                                .fontWeight(.bold)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 12)
                                        .background(settings.theme.accentGradient)
                                        .foregroundColor(.white)
                                        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                                    }
                                }
                            }
                            .padding(18)
                            .liquidGlass(cornerRadius: 26)

                            // Save & Export Actions (Save to Photos, Save to Files, Share)
                            VStack(alignment: .leading, spacing: 12) {
                                Label("Save & Export Video", systemImage: "square.and.arrow.down.on.square.fill")
                                    .font(.headline.weight(.bold))
                                    .foregroundColor(settings.theme.primaryText(isLight: isLight))

                                HStack(spacing: 12) {
                                    Button {
                                        cameraManager.saveVideoToPhotos(url: clip.url) { _, msg in
                                            showToast(msg)
                                        }
                                    } label: {
                                        VStack(spacing: 6) {
                                            Image(systemName: "photo.on.rectangle.angled")
                                                .font(.title2)
                                            Text("Save to Photos")
                                                .font(.caption.weight(.bold))
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 14)
                                        .background(settings.theme.accentGradient)
                                        .foregroundColor(.white)
                                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                    }

                                    Button {
                                        isShowingFilesExporter = true
                                    } label: {
                                        VStack(spacing: 6) {
                                            Image(systemName: "folder.fill.badge.plus")
                                                .font(.title2)
                                            Text("Save to Files")
                                                .font(.caption.weight(.bold))
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 14)
                                        .background(accent.opacity(0.18))
                                        .foregroundColor(accent)
                                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                    }

                                    Button {
                                        isShowingShareSheet = true
                                    } label: {
                                        VStack(spacing: 6) {
                                            Image(systemName: "square.and.arrow.up")
                                                .font(.title2)
                                            Text("Share Video")
                                                .font(.caption.weight(.bold))
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 14)
                                        .background(Color.white.opacity(0.10))
                                        .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                                    }
                                }
                            }
                            .padding(18)
                            .liquidGlass(cornerRadius: 26)

                            // Session Recorded Takes List
                            if cameraManager.recordedClips.count > 1 {
                                VStack(alignment: .leading, spacing: 10) {
                                    Text("All Recorded Takes")
                                        .font(.subheadline.weight(.bold))
                                        .foregroundColor(settings.theme.secondaryText(isLight: isLight))

                                    ForEach(cameraManager.recordedClips) { item in
                                        let isCurrent = (item.id == clip.id)
                                        Button {
                                            cameraManager.activeClipForEditor = item
                                            loadClip(item)
                                        } label: {
                                            HStack {
                                                Image(systemName: isCurrent ? "play.circle.fill" : "film")
                                                    .foregroundColor(accent)
                                                Text(item.title)
                                                    .font(.subheadline.weight(.semibold))
                                                    .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                                Spacer()
                                                Text(String(format: "%.1fs", item.durationSeconds))
                                                    .font(.caption.monospacedDigit())
                                                    .foregroundColor(settings.theme.secondaryText(isLight: isLight))
                                            }
                                            .padding(12)
                                            .background(isCurrent ? accent.opacity(0.16) : Color.white.opacity(0.05))
                                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                                        }
                                    }
                                }
                                .padding(18)
                                .liquidGlass(cornerRadius: 24)
                            }
                        } else {
                            VStack(spacing: 14) {
                                Image(systemName: "video.badge.waveform.fill")
                                    .font(.system(size: 52))
                                    .foregroundColor(accent)
                                Text("No Recorded Video Yet")
                                    .font(.title3.weight(.bold))
                                    .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                Text("Record a take in the Camera or Reading Screen to trim, preview, and save it to Photos or Files.")
                                    .font(.subheadline)
                                    .multilineTextAlignment(.center)
                                    .foregroundColor(settings.theme.secondaryText(isLight: isLight))
                            }
                            .padding(32)
                            .liquidGlass(cornerRadius: 26)
                        }
                    }
                    .padding(16)
                }

                if let toast = toastMessage {
                    VStack {
                        Spacer()
                        HStack(spacing: 10) {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.white)
                            Text(toast)
                                .font(.subheadline.weight(.bold))
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 18)
                        .padding(.vertical, 12)
                        .background(settings.theme.accentGradient)
                        .clipShape(Capsule())
                        .shadow(radius: 12)
                        .padding(.bottom, 24)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
            }
            .navigationTitle("Video Editor & Trim")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        player?.pause()
                        dismiss()
                    }
                    .fontWeight(.bold)
                    .foregroundColor(accent)
                }
            }
            .onAppear {
                if let clip = currentClip {
                    loadClip(clip)
                }
            }
            .onDisappear {
                player?.pause()
            }
            .sheet(isPresented: $isShowingShareSheet) {
                if let clip = currentClip {
                    ShareSheetView(activityItems: [clip.url])
                }
            }
            .sheet(isPresented: $isShowingFilesExporter) {
                if let clip = currentClip {
                    DocumentExportPicker(fileURL: clip.url) { saved in
                        if saved {
                            showToast("Saved video to Files!")
                        }
                    }
                }
            }
        }
    }

    private func loadClip(_ clip: RecordedClip) {
        player?.pause()
        let asset = AVURLAsset(url: clip.url)
        let dur = max(0.5, CMTimeGetSeconds(asset.duration))
        totalDuration = dur.isFinite ? dur : clip.durationSeconds
        startTime = 0.0
        endTime = totalDuration
        let newPlayer = AVPlayer(url: clip.url)
        newPlayer.isMuted = isMuted
        player = newPlayer
        newPlayer.play()
    }

    private func seekPlayer(to seconds: Double) {
        let cm = CMTime(seconds: max(0, seconds), preferredTimescale: 600)
        player?.seek(to: cm, toleranceBefore: .zero, toleranceAfter: .zero)
    }

    private func showToast(_ text: String) {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
            toastMessage = text
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) {
            withAnimation {
                if toastMessage == text {
                    toastMessage = nil
                }
            }
        }
    }
}
