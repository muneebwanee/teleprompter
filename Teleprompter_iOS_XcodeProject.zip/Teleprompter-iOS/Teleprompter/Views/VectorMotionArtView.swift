import SwiftUI

struct VectorMotionArtView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    var speedMultiplier: Double = 1.0

    var body: some View {
        let accent = settings.theme.accentTint
        TimelineView(.animation) { timeline in
            let t = timeline.date.timeIntervalSinceReferenceDate * speedMultiplier
            Canvas { context, size in
                let midY = size.height * 0.5
                let width = size.width

                for layer in 0..<3 {
                    var path = Path()
                    let amp = CGFloat(10 + layer * 6)
                    let freq = Double(layer + 1) * 0.018
                    let phase = t * (1.3 + Double(layer) * 0.45)

                    path.move(to: CGPoint(x: 0, y: midY))
                    for x in stride(from: 0, through: width, by: 4) {
                        let y = midY + sin(Double(x) * freq + phase) * amp * cos(Double(x) * 0.007 - phase * 0.5)
                        path.addLine(to: CGPoint(x: x, y: y))
                    }

                    let opacity = 0.80 - Double(layer) * 0.24
                    context.stroke(
                        path,
                        with: .linearGradient(
                            Gradient(colors: [
                                accent.opacity(opacity),
                                accent.opacity(opacity * 0.35)
                            ]),
                            startPoint: CGPoint(x: 0, y: midY),
                            endPoint: CGPoint(x: width, y: midY)
                        ),
                        lineWidth: CGFloat(2.4 - Double(layer) * 0.5)
                    )
                }
            }
        }
    }
}
