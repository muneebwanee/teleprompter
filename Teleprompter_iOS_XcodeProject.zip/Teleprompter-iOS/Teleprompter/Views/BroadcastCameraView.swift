import SwiftUI
import AVFoundation

struct BroadcastCameraView: View {
    let script: ScriptItem
    @EnvironmentObject var settings: TeleprompterSettings
    @EnvironmentObject var cameraManager: CameraRecordingManager
    @Environment(\.dismiss) private var dismiss

    @State private var selectedZoom: CGFloat = 1.0
    @State private var showGrid: Bool = true
    @State private var overlayOpacity: Double = 0.72
    @State private var isScrollingScript: Bool = false
    @State private var scriptScrollOffset: CGFloat = 0.0
    @State private var recordingSeconds: Int = 0

    private let zoomLevels: [CGFloat] = [1.0, 2.0, 3.0]
    private let frameTimer = Timer.publish(every: 1.0 / 60.0, on: .main, in: .common).autoconnect()
    private let secondTimer = Timer.publish(every: 1.0, on: .main, in: .common).autoconnect()

    var body: some View {
        let accent = settings.theme.accentTint

        ZStack {
            // Fullscreen Live iOS Camera Feed (Backed by AVCaptureVideoPreviewLayer)
            CameraPreviewRepresentable(session: cameraManager.session)
                .ignoresSafeArea()

            // Subtle vignette for readability
            LinearGradient(
                colors: [Color.black.opacity(0.55), Color.clear, Color.black.opacity(0.65)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            .allowsHitTesting(false)

            // Rule of Thirds Framing Grid
            if showGrid {
                GeometryReader { geo in
                    Path { path in
                        let w = geo.size.width
                        let h = geo.size.height
                        path.move(to: CGPoint(x: w / 3, y: 0))
                        path.addLine(to: CGPoint(x: w / 3, y: h))
                        path.move(to: CGPoint(x: (w / 3) * 2, y: 0))
                        path.addLine(to: CGPoint(x: (w / 3) * 2, y: h))
                        path.move(to: CGPoint(x: 0, y: h / 3))
                        path.addLine(to: CGPoint(x: w, y: h / 3))
                        path.move(to: CGPoint(x: 0, y: (h / 3) * 2))
                        path.addLine(to: CGPoint(x: w, y: (h / 3) * 2))
                    }
                    .stroke(Color.white.opacity(0.22), lineWidth: 1)
                }
                .ignoresSafeArea()
                .allowsHitTesting(false)
            }

            VStack(spacing: 12) {
                // Top Camera Studio Bar
                HStack(spacing: 12) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title2)
                            .foregroundColor(.white)
                    }

                    HStack(spacing: 6) {
                        Circle()
                            .fill(cameraManager.isRecording ? Color.red : accent)
                            .frame(width: 8, height: 8)
                        Text(cameraManager.isRecording
                             ? String(format: "REC %02d:%02d", recordingSeconds / 60, recordingSeconds % 60)
                             : (cameraManager.usingFrontCamera ? "Front Camera" : "Back Camera"))
                            .font(.caption.weight(.bold).monospacedDigit())
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(.ultraThinMaterial)
                    .clipShape(Capsule())

                    Spacer()

                    // Front / Back Camera Switcher Pills
                    HStack(spacing: 6) {
                        Button {
                            cameraManager.setCamera(front: true)
                        } label: {
                            Text("Front")
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(cameraManager.usingFrontCamera ? accent : Color.black.opacity(0.45))
                                .foregroundColor(.white)
                                .clipShape(Capsule())
                        }

                        Button {
                            cameraManager.setCamera(front: false)
                        } label: {
                            Text("Back")
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(!cameraManager.usingFrontCamera ? accent : Color.black.opacity(0.45))
                                .foregroundColor(.white)
                                .clipShape(Capsule())
                        }
                    }

                    // Open Post-Capture Video Editor & Trimmer
                    Button {
                        cameraManager.showPostCaptureEditor = true
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "scissors")
                            Text("Clips (\(cameraManager.recordedClips.count))")
                                .font(.caption.weight(.bold))
                        }
                        .padding(.horizontal, 11)
                        .padding(.vertical, 6)
                        .background(.ultraThinMaterial)
                        .foregroundColor(.white)
                        .clipShape(Capsule())
                    }
                }
                .padding(.horizontal, 18)
                .padding(.top, 8)

                // Floating Translucent Script Overlay Docked Near Top Lens
                VStack(alignment: .leading, spacing: 10) {
                    HStack(spacing: 10) {
                        Button {
                            withAnimation(.spring()) {
                                isScrollingScript.toggle()
                            }
                        } label: {
                            HStack(spacing: 5) {
                                Image(systemName: isScrollingScript ? "pause.fill" : "play.fill")
                                Text(isScrollingScript ? "Pause Script" : "Scroll Script")
                            }
                            .font(.caption.weight(.bold))
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(settings.theme.accentGradient)
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                        }

                        Button {
                            withAnimation(.spring()) {
                                scriptScrollOffset = 0
                            }
                        } label: {
                            Image(systemName: "arrow.counterclockwise")
                                .font(.caption.weight(.bold))
                                .foregroundColor(.white)
                                .padding(6)
                                .background(Color.white.opacity(0.14))
                                .clipShape(Circle())
                        }

                        Spacer()

                        Text("See-Through")
                            .font(.caption2.weight(.semibold))
                            .foregroundColor(.white.opacity(0.75))
                        Slider(value: $overlayOpacity, in: 0.20...0.92)
                            .frame(width: 85)
                            .tint(accent)
                    }

                    ScrollView(.vertical, showsIndicators: false) {
                        Text(script.content)
                            .font(.system(size: max(20, settings.fontSize * 0.65), weight: .semibold, design: settings.fontDesign.swiftUIFontDesign))
                            .foregroundColor(.white)
                            .lineSpacing(8)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .offset(y: -scriptScrollOffset)
                    }
                    .frame(height: 185)
                    .clipped()
                }
                .padding(16)
                .background(Color.black.opacity(overlayOpacity))
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .stroke(accent.opacity(0.55), lineWidth: 1.2)
                )
                .padding(.horizontal, 18)

                Spacer()

                // Bottom Camera Controls Bar
                VStack(spacing: 14) {
                    // Zoom Dial (1x, 2x, 3x) + Flip Camera
                    HStack(spacing: 12) {
                        ForEach(zoomLevels, id: \.self) { z in
                            Button {
                                selectedZoom = z
                                cameraManager.setZoom(z)
                            } label: {
                                Text("\(Int(z))x")
                                    .font(.caption.weight(.bold))
                                    .frame(width: 38, height: 38)
                                    .background(selectedZoom == z ? accent : Color.black.opacity(0.55))
                                    .foregroundColor(.white)
                                    .clipShape(Circle())
                            }
                        }

                        Button {
                            cameraManager.flipCamera()
                        } label: {
                            Label(cameraManager.usingFrontCamera ? "Switch to Back" : "Switch to Front", systemImage: "arrow.triangle.2.circlepath.camera.fill")
                                .font(.caption.weight(.bold))
                                .padding(.horizontal, 12)
                                .padding(.vertical, 9)
                                .background(Color.black.opacity(0.55))
                                .foregroundColor(.white)
                                .clipShape(Capsule())
                        }
                    }

                    // Shutter & Tools Row
                    HStack(spacing: 32) {
                        Button {
                            showGrid.toggle()
                        } label: {
                            VStack(spacing: 4) {
                                Image(systemName: "grid")
                                    .font(.title3)
                                Text("Grid")
                                    .font(.caption2.weight(.semibold))
                            }
                            .foregroundColor(showGrid ? accent : .white)
                        }

                        // Record Video Button (Auto-opens Trim & Save Editor when stopped)
                        Button {
                            if !cameraManager.isRecording {
                                recordingSeconds = 0
                                isScrollingScript = true
                            } else {
                                isScrollingScript = false
                            }
                            cameraManager.toggleRecording()
                        } label: {
                            ZStack {
                                Circle()
                                    .stroke(Color.white, lineWidth: 4)
                                    .frame(width: 72, height: 72)
                                RoundedRectangle(cornerRadius: cameraManager.isRecording ? 10 : 32, style: .continuous)
                                    .fill(Color.red)
                                    .frame(width: cameraManager.isRecording ? 30 : 58, height: cameraManager.isRecording ? 30 : 58)
                                    .animation(.spring(response: 0.25, dampingFraction: 0.75), value: cameraManager.isRecording)
                            }
                        }

                        Button {
                            cameraManager.showPostCaptureEditor = true
                        } label: {
                            VStack(spacing: 4) {
                                Image(systemName: "slider.horizontal.below.rectangle")
                                    .font(.title3)
                                Text("Edit Clip")
                                    .font(.caption2.weight(.semibold))
                            }
                            .foregroundColor(.white)
                        }
                    }
                }
                .padding(16)
                .background(.ultraThinMaterial)
                .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
                .padding(.horizontal, 18)
                .padding(.bottom, 12)
            }
        }
        .onAppear {
            cameraManager.configureIfNeeded()
        }
        .onReceive(frameTimer) { _ in
            guard isScrollingScript else { return }
            let pixelsPerSec = CGFloat(settings.wordsPerMinute) * 0.42
            scriptScrollOffset += pixelsPerSec / 60.0
        }
        .onReceive(secondTimer) { _ in
            if cameraManager.isRecording {
                recordingSeconds += 1
            }
        }
        .sheet(isPresented: $cameraManager.showPostCaptureEditor) {
            VideoClipEditorView()
                .environmentObject(cameraManager)
                .environmentObject(settings)
        }
    }
}
