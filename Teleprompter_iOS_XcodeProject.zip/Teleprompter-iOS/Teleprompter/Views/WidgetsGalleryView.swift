import SwiftUI
import UIKit

struct WidgetCardItem: Identifiable, Equatable {
    let id: String
    var title: String
    var sizeBadge: String
    var subtitle: String
    var icon: String
    var isAddedToHome: Bool
}

struct WidgetsGalleryView: View {
    @EnvironmentObject var scriptStore: ScriptStore
    @EnvironmentObject var settings: TeleprompterSettings
    @EnvironmentObject var cameraManager: CameraRecordingManager
    @Environment(\.dismiss) private var dismiss

    var onLaunchPrompter: () -> Void
    var onOpenCamera: () -> Void

    @State private var isEditingHomeScreen: Bool = false
    @State private var jigglePhase: Bool = false
    @State private var interactiveDialAngle: Double = 0.0
    @State private var tapTimes: [Date] = []
    @State private var activePresetID: String = "keynote"
    @State private var eqBars: [CGFloat] = Array(repeating: 0.35, count: 18)

    @State private var widgets: [WidgetCardItem] = [
        WidgetCardItem(id: "w_quick_script", title: "Quick Script Launcher", sizeBadge: "SMALL • 2×2", subtitle: "1-tap launch into your pinned script with word & time readout", icon: "play.rectangle.fill", isAddedToHome: true),
        WidgetCardItem(id: "w_camera_rig", title: "Dual Camera Studio Rig", sizeBadge: "MEDIUM • 4×2", subtitle: "Instant Front Camera, Back Camera, or Mirror Glass Rig", icon: "camera.aperture", isAddedToHome: true),
        WidgetCardItem(id: "w_pace_rings", title: "Speaking Pace & Goal Rings", sizeBadge: "SMALL • 2×2", subtitle: "Live WPM speed ring and daily speaking duration tracker", icon: "gauge.with.dots.needle.67percent", isAddedToHome: true),
        WidgetCardItem(id: "w_live_reader", title: "Teleprompter Script Reader", sizeBadge: "LARGE • 4×4", subtitle: "Preview script lines on your Home Screen with Easy Read", icon: "text.viewfinder", isAddedToHome: true),
        WidgetCardItem(id: "w_lock_screen", title: "Lock Screen & StandBy Bar", sizeBadge: "LOCK SCREEN", subtitle: "Launch Teleprompter or Camera directly from Lock Screen", icon: "lock.rectangle.on.rectangle.fill", isAddedToHome: true)
    ]

    private let eqTimer = Timer.publish(every: 0.16, on: .main, in: .common).autoconnect()

    var currentScript: ScriptItem {
        scriptStore.selectedScript ?? ScriptStore.sampleScripts[0]
    }

    var body: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint

        NavigationStack {
            ZStack {
                settings.theme.backgroundColor(isLight: isLight)
                    .ignoresSafeArea()

                RadialGradient(
                    colors: [accent.opacity(isLight ? 0.16 : 0.25), Color.clear],
                    center: .topLeading,
                    startRadius: 20,
                    endRadius: 560
                )
                .ignoresSafeArea()

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 18) {
                        // 1. Top Interactive Banner with "Edit Home Screen" Jiggle Toggle
                        ZStack(alignment: .leading) {
                            VectorMotionArtView(speedMultiplier: 1.2)
                                .frame(height: 86)

                            HStack(spacing: 14) {
                                GlassVectorIconBadge(symbol: "square.grid.2x2.fill", accent: accent, gradient: settings.theme.accentGradient)

                                VStack(alignment: .leading, spacing: 3) {
                                    Text("Interactive Widgets & Controls")
                                        .font(.headline.weight(.bold))
                                        .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                    Text(isEditingHomeScreen ? "Jiggle Mode Active: Tap + or - to customize widgets" : "Interactive micro-controls & Home Screen widgets")
                                        .font(.caption)
                                        .foregroundColor(settings.theme.secondaryText(isLight: isLight))
                                }

                                Spacer()

                                Button {
                                    triggerHaptic()
                                    withAnimation(.spring(response: 0.32, dampingFraction: 0.72)) {
                                        isEditingHomeScreen.toggle()
                                        jigglePhase = isEditingHomeScreen
                                    }
                                } label: {
                                    HStack(spacing: 6) {
                                        Image(systemName: isEditingHomeScreen ? "checkmark.circle.fill" : "slider.horizontal.below.square.and.square.filled")
                                        Text(isEditingHomeScreen ? "Done Editing" : "Edit Widgets")
                                            .fontWeight(.bold)
                                    }
                                    .font(.caption)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 9)
                                    .background(isEditingHomeScreen ? AnyShapeStyle(settings.theme.accentGradient) : AnyShapeStyle(Color.primary.opacity(0.08)))
                                    .foregroundColor(isEditingHomeScreen ? .white : settings.theme.primaryText(isLight: isLight))
                                    .clipShape(Capsule())
                                }
                                .buttonStyle(.plain)
                            }
                            .padding(.horizontal, 16)
                        }
                        .liquidGlass(cornerRadius: 24, isHighlighted: true)

                        // 2. Interactive Micro-Interaction Studio Cards (Speed Dial + Eye-Line Calibrator + Pace Coach)
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Image(systemName: "dial.medium.fill")
                                    .foregroundColor(accent)
                                Text("Interactive Studio Micro-Controls")
                                    .font(.headline.weight(.bold))
                                    .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                Spacer()
                                Text("LIVE TOUCH")
                                    .font(.system(size: 10, weight: .heavy))
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 3)
                                    .background(accent.opacity(0.18))
                                    .foregroundColor(accent)
                                    .clipShape(Capsule())
                            }

                            HStack(spacing: 12) {
                                // Card A: Interactive Rotary WPM Speed Dial
                                VStack(spacing: 10) {
                                    ZStack {
                                        Circle()
                                            .stroke(Color.primary.opacity(0.10), lineWidth: 10)
                                            .frame(width: 112, height: 112)

                                        Circle()
                                            .trim(from: 0.0, to: CGFloat((settings.wordsPerMinute - 60) / 200.0))
                                            .stroke(settings.theme.accentGradient, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                                            .frame(width: 112, height: 112)
                                            .rotationEffect(.degrees(-90))
                                            .animation(.spring(response: 0.28, dampingFraction: 0.78), value: settings.wordsPerMinute)

                                        VStack(spacing: 2) {
                                            Text("\(Int(settings.wordsPerMinute))")
                                                .font(.system(size: 26, weight: .heavy, design: .rounded))
                                                .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                            Text("WPM SPEED")
                                                .font(.system(size: 9, weight: .bold))
                                                .foregroundColor(accent)
                                        }
                                    }
                                    .padding(.top, 4)

                                    HStack(spacing: 8) {
                                        Button {
                                            triggerHaptic()
                                            settings.wordsPerMinute = max(60, settings.wordsPerMinute - 10)
                                        } label: {
                                            Image(systemName: "minus")
                                                .font(.caption.weight(.bold))
                                                .frame(width: 30, height: 30)
                                                .background(Color.primary.opacity(0.08))
                                                .clipShape(Circle())
                                        }
                                        .buttonStyle(.plain)

                                        Button {
                                            tapPaceCoach()
                                        } label: {
                                            Text("Tap Tempo")
                                                .font(.caption2.weight(.bold))
                                                .padding(.horizontal, 10)
                                                .padding(.vertical, 7)
                                                .background(settings.theme.accentGradient)
                                                .foregroundColor(.white)
                                                .clipShape(Capsule())
                                        }
                                        .buttonStyle(.plain)

                                        Button {
                                            triggerHaptic()
                                            settings.wordsPerMinute = min(260, settings.wordsPerMinute + 10)
                                        } label: {
                                            Image(systemName: "plus")
                                                .font(.caption.weight(.bold))
                                                .frame(width: 30, height: 30)
                                                .background(Color.primary.opacity(0.08))
                                                .clipShape(Circle())
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                                .frame(maxWidth: .infinity)
                                .padding(14)
                                .liquidGlass(cornerRadius: 22)

                                // Card B: Interactive Eye-Line & Optical Mirror Calibrator
                                VStack(alignment: .leading, spacing: 10) {
                                    HStack {
                                        GlassVectorIconBadge(symbol: "viewfinder", accent: accent, gradient: settings.theme.accentGradient, size: 30)
                                        VStack(alignment: .leading, spacing: 1) {
                                            Text("Eye-Line & Mirror")
                                                .font(.subheadline.weight(.bold))
                                                .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                            Text("Height: \(Int(settings.eyeLineVerticalRatio * 100))%")
                                                .font(.caption2)
                                                .foregroundColor(accent)
                                        }
                                    }

                                    // Mini Interactive Stage Preview with Draggable Eye-Line
                                    GeometryReader { geo in
                                        ZStack {
                                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                                .fill(Color.black.opacity(0.75))

                                            VStack(spacing: 4) {
                                                RoundedRectangle(cornerRadius: 3).fill(accent).frame(height: 5).padding(.horizontal, 14)
                                                RoundedRectangle(cornerRadius: 3).fill(Color.white.opacity(0.8)).frame(height: 5).padding(.horizontal, 22)
                                                RoundedRectangle(cornerRadius: 3).fill(Color.white.opacity(0.35)).frame(height: 5).padding(.horizontal, 30)
                                            }
                                            .scaleEffect(x: settings.mirrorHorizontal ? -1 : 1, y: settings.mirrorVertical ? -1 : 1)

                                            RoundedRectangle(cornerRadius: 4)
                                                .fill(accent.opacity(0.28))
                                                .frame(height: 16)
                                                .overlay(
                                                    RoundedRectangle(cornerRadius: 4)
                                                        .stroke(accent, lineWidth: 1)
                                                )
                                                .position(x: geo.size.width / 2, y: geo.size.height * settings.eyeLineVerticalRatio)
                                        }
                                        .gesture(
                                            DragGesture(minimumDistance: 0)
                                                .onChanged { val in
                                                    let ratio = min(0.75, max(0.18, val.location.y / max(1, geo.size.height)))
                                                    settings.eyeLineVerticalRatio = ratio
                                                }
                                        )
                                    }
                                    .frame(height: 64)

                                    HStack(spacing: 6) {
                                        Button {
                                            triggerHaptic()
                                            withAnimation(.spring()) { settings.mirrorHorizontal.toggle() }
                                        } label: {
                                            Text("Mirror X")
                                                .font(.caption2.weight(.bold))
                                                .frame(maxWidth: .infinity)
                                                .padding(.vertical, 6)
                                                .background(settings.mirrorHorizontal ? accent : Color.primary.opacity(0.08))
                                                .foregroundColor(settings.mirrorHorizontal ? .white : settings.theme.primaryText(isLight: isLight))
                                                .clipShape(Capsule())
                                        }
                                        .buttonStyle(.plain)

                                        Button {
                                            triggerHaptic()
                                            withAnimation(.spring()) { settings.easyReadEnabled.toggle() }
                                        } label: {
                                            Text("Easy Read")
                                                .font(.caption2.weight(.bold))
                                                .frame(maxWidth: .infinity)
                                                .padding(.vertical, 6)
                                                .background(settings.easyReadEnabled ? accent : Color.primary.opacity(0.08))
                                                .foregroundColor(settings.easyReadEnabled ? .white : settings.theme.primaryText(isLight: isLight))
                                                .clipShape(Capsule())
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                                .frame(maxWidth: .infinity)
                                .padding(14)
                                .liquidGlass(cornerRadius: 22)
                            }
                        }

                        // 3. Home Screen & Lock Screen Widgets Showcase (Selectable in Edit Mode)
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Image(systemName: "apps.iphone")
                                    .foregroundColor(accent)
                                Text("iOS & iPadOS Home Screen Widgets")
                                    .font(.headline.weight(.bold))
                                    .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                Spacer()
                                Text("\(widgets.filter { $0.isAddedToHome }.count) Active")
                                    .font(.caption.weight(.bold))
                                    .foregroundColor(accent)
                            }

                            // Widget 1 & Widget 3 Side-by-Side (Small 2x2 Widgets)
                            HStack(spacing: 12) {
                                // Small 2x2 Pinned Script Widget
                                widgetPreviewContainer(item: $widgets[0]) {
                                    VStack(alignment: .leading, spacing: 8) {
                                        HStack {
                                            GlassVectorIconBadge(symbol: "play.fill", accent: accent, gradient: settings.theme.accentGradient, size: 26)
                                            Spacer()
                                            Text("2×2")
                                                .font(.system(size: 9, weight: .heavy))
                                                .foregroundColor(accent)
                                        }
                                        Text(currentScript.title)
                                            .font(.subheadline.weight(.bold))
                                            .foregroundColor(.white)
                                            .lineLimit(2)
                                        Spacer()
                                        HStack {
                                            Text("\(currentScript.wordCount)w • \(currentScript.formattedDuration)")
                                                .font(.caption2.weight(.semibold))
                                                .foregroundColor(.white.opacity(0.65))
                                            Spacer()
                                        }
                                        Button {
                                            triggerHaptic()
                                            onLaunchPrompter()
                                        } label: {
                                            Text("Prompt ▶")
                                                .font(.caption.weight(.bold))
                                                .frame(maxWidth: .infinity)
                                                .padding(.vertical, 6)
                                                .background(settings.theme.accentGradient)
                                                .foregroundColor(.white)
                                                .clipShape(Capsule())
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }

                                // Small 2x2 Speaking Pace & Goal Rings Widget
                                widgetPreviewContainer(item: $widgets[2]) {
                                    VStack(alignment: .leading, spacing: 8) {
                                        HStack {
                                            GlassVectorIconBadge(symbol: "waveform.path.ecg", accent: accent, gradient: settings.theme.accentGradient, size: 26)
                                            Spacer()
                                            Text("2×2 RINGS")
                                                .font(.system(size: 9, weight: .heavy))
                                                .foregroundColor(accent)
                                        }
                                        HStack(spacing: 10) {
                                            ZStack {
                                                Circle().stroke(Color.white.opacity(0.14), lineWidth: 5).frame(width: 46, height: 46)
                                                Circle()
                                                    .trim(from: 0, to: 0.78)
                                                    .stroke(settings.theme.accentGradient, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                                                    .frame(width: 46, height: 46)
                                                    .rotationEffect(.degrees(-90))
                                                Text("\(Int(settings.wordsPerMinute))")
                                                    .font(.system(size: 12, weight: .heavy, design: .rounded))
                                                    .foregroundColor(.white)
                                            }
                                            VStack(alignment: .leading, spacing: 2) {
                                                Text("Pace Goal")
                                                    .font(.caption.weight(.bold))
                                                    .foregroundColor(.white)
                                                Text("\(Int(settings.wordsPerMinute)) WPM")
                                                    .font(.caption2)
                                                    .foregroundColor(accent)
                                                Text("\(scriptStore.scripts.count) Scripts")
                                                    .font(.caption2)
                                                    .foregroundColor(.white.opacity(0.6))
                                            }
                                        }
                                        Spacer()
                                        // Live mini spectrum bars inside widget
                                        HStack(alignment: .bottom, spacing: 3) {
                                            ForEach(0..<12, id: \.self) { idx in
                                                RoundedRectangle(cornerRadius: 2)
                                                    .fill(settings.theme.accentGradient)
                                                    .frame(height: max(4, eqBars[idx] * 22))
                                            }
                                        }
                                        .frame(height: 22)
                                    }
                                }
                            }

                            // Medium 4x2 Dual Camera Studio Rig Widget
                            widgetPreviewContainer(item: $widgets[1]) {
                                VStack(alignment: .leading, spacing: 10) {
                                    HStack {
                                        GlassVectorIconBadge(symbol: "camera.aperture", accent: accent, gradient: settings.theme.accentGradient, size: 28)
                                        VStack(alignment: .leading, spacing: 1) {
                                            Text("Dual Camera & Optical Rig")
                                                .font(.subheadline.weight(.bold))
                                                .foregroundColor(.white)
                                            Text("MEDIUM • 4×2 HOME SCREEN WIDGET")
                                                .font(.system(size: 9, weight: .heavy))
                                                .foregroundColor(accent)
                                        }
                                        Spacer()
                                        Button {
                                            triggerHaptic()
                                            onOpenCamera()
                                        } label: {
                                            Text("Open Camera")
                                                .font(.caption.weight(.bold))
                                                .padding(.horizontal, 12)
                                                .padding(.vertical, 6)
                                                .background(settings.theme.accentGradient)
                                                .foregroundColor(.white)
                                                .clipShape(Capsule())
                                        }
                                        .buttonStyle(.plain)
                                    }

                                    HStack(spacing: 8) {
                                        quickRigPill(title: "Front Cam", subtitle: "TrueDepth", icon: "person.crop.rectangle.fill") {
                                            cameraManager.setCamera(front: true)
                                            onOpenCamera()
                                        }
                                        quickRigPill(title: "Back Cam", subtitle: "4K Wide", icon: "camera.fill") {
                                            cameraManager.setCamera(front: false)
                                            onOpenCamera()
                                        }
                                        quickRigPill(title: "Mirror Rig", subtitle: "Flip X", icon: "arrow.left.and.right.righttriangle.left.righttriangle.right.fill") {
                                            settings.mirrorHorizontal = true
                                            onLaunchPrompter()
                                        }
                                    }
                                }
                            }

                            // Large 4x4 Teleprompter Live Script Reader Widget
                            widgetPreviewContainer(item: $widgets[3]) {
                                VStack(alignment: .leading, spacing: 10) {
                                    HStack {
                                        GlassVectorIconBadge(symbol: "text.viewfinder", accent: accent, gradient: settings.theme.accentGradient, size: 28)
                                        VStack(alignment: .leading, spacing: 1) {
                                            Text("Live Teleprompter Script Reader")
                                                .font(.subheadline.weight(.bold))
                                                .foregroundColor(.white)
                                            Text("LARGE • 4×4 INTERACTIVE WIDGET")
                                                .font(.system(size: 9, weight: .heavy))
                                                .foregroundColor(accent)
                                        }
                                        Spacer()
                                        Button {
                                            triggerHaptic()
                                            settings.easyReadEnabled.toggle()
                                        } label: {
                                            Text(settings.easyReadEnabled ? "Easy Read ON" : "Easy Read")
                                                .font(.caption2.weight(.bold))
                                                .padding(.horizontal, 10)
                                                .padding(.vertical, 5)
                                                .background(settings.easyReadEnabled ? accent : Color.white.opacity(0.12))
                                                .foregroundColor(.white)
                                                .clipShape(Capsule())
                                        }
                                        .buttonStyle(.plain)
                                    }

                                    Text(currentScript.content.replacingOccurrences(of: "[PAUSE]", with: "•").replacingOccurrences(of: "[EMPHASIS]", with: ""))
                                        .font(.system(size: 14, weight: settings.easyReadEnabled ? .bold : .medium, design: settings.fontDesign.swiftUIFontDesign))
                                        .foregroundColor(.white.opacity(0.9))
                                        .lineLimit(3)
                                        .padding(12)
                                        .frame(maxWidth: .infinity, alignment: .leading)
                                        .background(Color.black.opacity(0.45))
                                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))

                                    HStack {
                                        Label("\(currentScript.wordCount) words • \(currentScript.formattedDuration)", systemImage: "timer")
                                            .font(.caption2.weight(.semibold))
                                            .foregroundColor(.white.opacity(0.65))
                                        Spacer()
                                        Button {
                                            triggerHaptic()
                                            onLaunchPrompter()
                                        } label: {
                                            Label("Start Reading", systemImage: "play.fill")
                                                .font(.caption.weight(.bold))
                                                .padding(.horizontal, 14)
                                                .padding(.vertical, 7)
                                                .background(settings.theme.accentGradient)
                                                .foregroundColor(.white)
                                                .clipShape(Capsule())
                                        }
                                        .buttonStyle(.plain)
                                    }
                                }
                            }

                            // Lock Screen & StandBy Widget Card
                            widgetPreviewContainer(item: $widgets[4]) {
                                HStack(spacing: 14) {
                                    GlassVectorIconBadge(symbol: "lock.rectangle.on.rectangle.fill", accent: accent, gradient: settings.theme.accentGradient, size: 36)
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text("Lock Screen & iPad StandBy Widget")
                                            .font(.subheadline.weight(.bold))
                                            .foregroundColor(.white)
                                        Text("Circular & Rectangular Lock Screen widgets included in Teleprompter")
                                            .font(.caption2)
                                            .foregroundColor(.white.opacity(0.65))
                                    }
                                    Spacer()
                                    Text("READY")
                                        .font(.system(size: 10, weight: .heavy))
                                        .padding(.horizontal, 9)
                                        .padding(.vertical, 4)
                                        .background(accent.opacity(0.22))
                                        .foregroundColor(accent)
                                        .clipShape(Capsule())
                                }
                            }
                        }
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Widgets & Interactive UI")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                        .fontWeight(.bold)
                        .foregroundColor(accent)
                }
            }
            .onReceive(eqTimer) { _ in
                withAnimation(.easeInOut(duration: 0.15)) {
                    for i in eqBars.indices {
                        eqBars[i] = CGFloat.random(in: 0.22...0.95)
                    }
                }
            }
        }
    }

    @ViewBuilder
    private func widgetPreviewContainer<Content: View>(item: Binding<WidgetCardItem>, @ViewBuilder content: () -> Content) -> some View {
        let accent = settings.theme.accentTint
        ZStack(alignment: .topTrailing) {
            VStack(alignment: .leading, spacing: 8) {
                content()
            }
            .padding(16)
            .frame(maxWidth: .infinity, minHeight: 150)
            .background(
                LinearGradient(
                    colors: [Color(red: 0.10, green: 0.10, blue: 0.14), Color(red: 0.04, green: 0.04, blue: 0.06)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 24, style: .continuous)
                    .stroke(item.wrappedValue.isAddedToHome ? accent.opacity(0.65) : Color.white.opacity(0.14), lineWidth: item.wrappedValue.isAddedToHome ? 1.5 : 1)
            )
            .shadow(color: Color.black.opacity(0.45), radius: 14, x: 0, y: 8)
            .opacity(item.wrappedValue.isAddedToHome ? 1.0 : 0.55)
            .rotationEffect(.degrees(isEditingHomeScreen ? (jigglePhase ? -1.1 : 1.1) : 0))
            .animation(
                isEditingHomeScreen
                    ? .easeInOut(duration: 0.14).repeatForever(autoreverses: true)
                    : .spring(response: 0.3, dampingFraction: 0.8),
                value: isEditingHomeScreen
            )

            if isEditingHomeScreen {
                Button {
                    triggerHaptic()
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.75)) {
                        item.wrappedValue.isAddedToHome.toggle()
                    }
                } label: {
                    Image(systemName: item.wrappedValue.isAddedToHome ? "minus.circle.fill" : "plus.circle.fill")
                        .font(.title2)
                        .foregroundColor(item.wrappedValue.isAddedToHome ? .red : .green)
                        .background(Circle().fill(Color.white))
                }
                .buttonStyle(.plain)
                .offset(x: 6, y: -6)
            }
        }
    }

    private func quickRigPill(title: String, subtitle: String, icon: String, action: @escaping () -> Void) -> some View {
        let accent = settings.theme.accentTint
        return Button {
            triggerHaptic()
            action()
        } label: {
            VStack(alignment: .leading, spacing: 4) {
                Image(systemName: icon)
                    .font(.caption.weight(.bold))
                    .foregroundColor(accent)
                Text(title)
                    .font(.caption.weight(.bold))
                    .foregroundColor(.white)
                Text(subtitle)
                    .font(.system(size: 10))
                    .foregroundColor(.white.opacity(0.6))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(10)
            .background(Color.white.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    private func tapPaceCoach() {
        triggerHaptic()
        let now = Date()
        tapTimes.append(now)
        if tapTimes.count > 6 { tapTimes.removeFirst() }
        if tapTimes.count >= 2 {
            var intervals: [Double] = []
            for i in 1..<tapTimes.count {
                intervals.append(tapTimes[i].timeIntervalSince(tapTimes[i - 1]))
            }
            let avg = intervals.reduce(0, +) / Double(intervals.count)
            if avg > 0.1 {
                let wpm = min(260, max(60, round((60.0 / avg) * 1.25 / 5.0) * 5.0))
                withAnimation(.spring()) {
                    settings.wordsPerMinute = wpm
                }
            }
        }
    }

    private func triggerHaptic() {
        let gen = UIImpactFeedbackGenerator(style: .light)
        gen.impactOccurred()
    }
}

struct GlassVectorIconBadge: View {
    let symbol: String
    let accent: Color
    let gradient: LinearGradient
    var size: CGFloat = 44

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.30, style: .continuous)
                .fill(gradient.opacity(0.22))
                .frame(width: size, height: size)
                .overlay(
                    RoundedRectangle(cornerRadius: size * 0.30, style: .continuous)
                        .stroke(accent.opacity(0.55), lineWidth: 1.2)
                )
            Image(systemName: symbol)
                .font(.system(size: size * 0.44, weight: .bold))
                .foregroundColor(accent)
        }
    }
}
