import SwiftUI

struct SettingsDrawerView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    @Environment(\.dismiss) private var dismiss

    private let themeColumns = [
        GridItem(.flexible(), spacing: 10),
        GridItem(.flexible(), spacing: 10)
    ]

    var body: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint

        NavigationStack {
            ZStack {
                settings.theme.backgroundColor(isLight: isLight)
                    .ignoresSafeArea()

                RadialGradient(
                    colors: [accent.opacity(isLight ? 0.16 : 0.24), Color.clear],
                    center: .topTrailing,
                    startRadius: 20,
                    endRadius: 520
                )
                .ignoresSafeArea()

                ScrollView(.vertical, showsIndicators: false) {
                    VStack(spacing: 18) {
                        // 1. Animated Vector Motion Header Card
                        ZStack(alignment: .leading) {
                            VectorMotionArtView(speedMultiplier: 1.1)
                                .frame(height: 82)

                            HStack(spacing: 14) {
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .fill(settings.theme.accentGradient)
                                    .frame(width: 52, height: 52)
                                    .overlay(
                                        Image(systemName: "slider.horizontal.3")
                                            .font(.title2.weight(.bold))
                                            .foregroundColor(.white)
                                    )
                                    .shadow(color: accent.opacity(0.45), radius: 10, x: 0, y: 5)

                                VStack(alignment: .leading, spacing: 3) {
                                    Text("Customize Your Studio")
                                        .font(.headline.weight(.bold))
                                        .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                    Text("Every change updates live with smooth motion")
                                        .font(.caption)
                                        .foregroundColor(settings.theme.secondaryText(isLight: isLight))
                                }
                                Spacer()
                            }
                            .padding(.horizontal, 16)
                        }
                        .liquidGlass(cornerRadius: 24, isHighlighted: true)

                        // 2. Colors & Look (Dark / Light Mode + 6 Interactive Theme Cards)
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Colors & Look", icon: "paintpalette.fill")

                            // Dark Mode vs Light Mode Selector
                            HStack(spacing: 10) {
                                modeCard(title: "Dark Mode", icon: "moon.stars.fill", selected: !settings.isLightMode) {
                                    withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                                        settings.isLightMode = false
                                    }
                                }
                                modeCard(title: "Light Mode", icon: "sun.max.fill", selected: settings.isLightMode) {
                                    withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                                        settings.isLightMode = true
                                    }
                                }
                            }

                            // 6 Color Themes Grid
                            LazyVGrid(columns: themeColumns, spacing: 10) {
                                ForEach(PrompterTheme.allCases) { item in
                                    let isSelected = (settings.theme == item)
                                    Button {
                                        withAnimation(.spring(response: 0.32, dampingFraction: 0.78)) {
                                            settings.theme = item
                                        }
                                    } label: {
                                        HStack(spacing: 10) {
                                            Circle()
                                                .fill(item.accentGradient)
                                                .frame(width: 28, height: 28)
                                                .overlay(
                                                    Circle()
                                                        .stroke(Color.white.opacity(0.6), lineWidth: isSelected ? 2 : 0.5)
                                                )
                                                .shadow(color: item.accentTint.opacity(0.55), radius: isSelected ? 8 : 0)

                                            VStack(alignment: .leading, spacing: 2) {
                                                Text(item.rawValue)
                                                    .font(.subheadline.weight(.bold))
                                                    .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                                Text(item.subtitle)
                                                    .font(.system(size: 10, weight: .medium))
                                                    .foregroundColor(settings.theme.secondaryText(isLight: isLight))
                                                    .lineLimit(1)
                                            }
                                            Spacer()
                                            if isSelected {
                                                Image(systemName: "checkmark.circle.fill")
                                                    .foregroundColor(item.accentTint)
                                            }
                                        }
                                        .padding(12)
                                        .background(
                                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                                .fill(isSelected ? item.accentTint.opacity(0.18) : Color.primary.opacity(0.05))
                                        )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 18, style: .continuous)
                                                .stroke(isSelected ? item.accentTint : Color.clear, lineWidth: 1.5)
                                        )
                                        .scaleEffect(isSelected ? 1.02 : 1.0)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                        .padding(18)
                        .liquidGlass(cornerRadius: 26)

                        // 3. Text & Fonts
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Text & Fonts", icon: "textformat.size")

                            LazyVGrid(columns: themeColumns, spacing: 10) {
                                ForEach(PrompterFontDesign.allCases) { font in
                                    let isSelected = (settings.fontDesign == font)
                                    Button {
                                        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                                            settings.fontDesign = font
                                        }
                                    } label: {
                                        VStack(alignment: .leading, spacing: 4) {
                                            HStack {
                                                Text("Aa")
                                                    .font(.system(size: 22, weight: .bold, design: font.swiftUIFontDesign))
                                                    .foregroundColor(isSelected ? accent : settings.theme.primaryText(isLight: isLight))
                                                Spacer()
                                                if isSelected {
                                                    Image(systemName: "checkmark.circle.fill")
                                                        .foregroundColor(accent)
                                                }
                                            }
                                            Text(font.rawValue)
                                                .font(.caption.weight(.bold))
                                                .foregroundColor(settings.theme.primaryText(isLight: isLight))
                                        }
                                        .padding(12)
                                        .background(
                                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                                .fill(isSelected ? accent.opacity(0.18) : Color.primary.opacity(0.05))
                                        )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                                .stroke(isSelected ? accent : Color.clear, lineWidth: 1.5)
                                        )
                                    }
                                    .buttonStyle(.plain)
                                }
                            }

                            sliderRow(title: "Text Size", valueText: "\(Int(settings.fontSize)) pt", value: $settings.fontSize, range: 24...76, step: 2)
                            sliderRow(title: "Line Spacing", valueText: "\(Int(settings.lineSpacing)) pt", value: $settings.lineSpacing, range: 6...32, step: 2)
                            sliderRow(title: "Side Margins", valueText: "\(Int(settings.horizontalMargin)) pt", value: $settings.horizontalMargin, range: 16...120, step: 4)
                        }
                        .padding(18)
                        .liquidGlass(cornerRadius: 26)

                        // 4. Reading Screen & Scroll Mode
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Reading Screen", icon: "play.rectangle.on.rectangle.fill")

                            LazyVGrid(columns: themeColumns, spacing: 10) {
                                ForEach(ScrollMode.allCases) { mode in
                                    let isSelected = (settings.scrollMode == mode)
                                    Button {
                                        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                                            settings.scrollMode = mode
                                        }
                                    } label: {
                                        HStack(spacing: 8) {
                                            Image(systemName: mode.icon)
                                                .foregroundColor(isSelected ? .white : accent)
                                            Text(mode.rawValue)
                                                .font(.caption.weight(.bold))
                                                .foregroundColor(isSelected ? .white : settings.theme.primaryText(isLight: isLight))
                                                .lineLimit(1)
                                            Spacer()
                                        }
                                        .padding(12)
                                        .background(
                                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                                .fill(isSelected ? AnyShapeStyle(settings.theme.accentGradient) : AnyShapeStyle(Color.primary.opacity(0.06)))
                                        )
                                    }
                                    .buttonStyle(.plain)
                                }
                            }

                            sliderRow(title: "Reading Speed", valueText: "\(Int(settings.wordsPerMinute)) WPM", value: $settings.wordsPerMinute, range: 60...260, step: 5)

                            Toggle("Easy Read (Bold Words)", isOn: $settings.easyReadEnabled)
                                .tint(accent)
                            Toggle("Dim Unread Lines", isOn: $settings.focusDimmingEnabled)
                                .tint(accent)
                            Toggle("Show Cue Badges ([PAUSE])", isOn: $settings.renderCueBadges)
                                .tint(accent)
                            Toggle("Show Eye-Line Guide Band", isOn: $settings.showEyeLineGuide)
                                .tint(accent)
                            Toggle("Flip Text Left-Right (Mirror X)", isOn: $settings.mirrorHorizontal)
                                .tint(accent)
                            Toggle("Flip Text Up-Down (Mirror Y)", isOn: $settings.mirrorVertical)
                                .tint(accent)
                        }
                        .foregroundColor(settings.theme.primaryText(isLight: isLight))
                        .padding(18)
                        .liquidGlass(cornerRadius: 26)

                        // 5. Camera & Countdown
                        VStack(alignment: .leading, spacing: 14) {
                            sectionTitle("Camera & Sound", icon: "video.badge.waveform.fill")

                            Toggle("Show Live Camera on Reading Screen", isOn: $settings.showCameraPreview)
                                .tint(accent)
                            Toggle("Full-Screen Camera Behind Text", isOn: $settings.fullScreenCameraStage)
                                .tint(accent)
                            Stepper("Start Countdown: \(settings.countdownSeconds) sec", value: $settings.countdownSeconds, in: 0...10)
                        }
                        .foregroundColor(settings.theme.primaryText(isLight: isLight))
                        .padding(18)
                        .liquidGlass(cornerRadius: 26)

                        // 6. Legal, Reset & About
                        VStack(alignment: .leading, spacing: 12) {
                            sectionTitle("Legal & App Info", icon: "shield.lefthalf.filled")

                            NavigationLink {
                                PrivacyPolicyView()
                                    .environmentObject(settings)
                            } label: {
                                navRow(title: "Privacy Policy", subtitle: "100% On-Device • Zero Tracking", icon: "lock.shield.fill")
                            }
                            .buttonStyle(.plain)

                            NavigationLink {
                                TermsOfServiceView()
                                    .environmentObject(settings)
                            } label: {
                                navRow(title: "Terms of Use", subtitle: "Script & Video Ownership", icon: "doc.text.fill")
                            }
                            .buttonStyle(.plain)

                            NavigationLink {
                                AboutDeveloperView()
                                    .environmentObject(settings)
                            } label: {
                                navRow(title: "About Teleprompter", subtitle: "Version 0.0.1 • Created by muneebwanee", icon: "viewfinder.circle.fill")
                            }
                            .buttonStyle(.plain)

                            Button {
                                settings.resetToDefaults()
                            } label: {
                                HStack {
                                    Image(systemName: "arrow.counterclockwise")
                                    Text("Reset All Settings to Default")
                                        .fontWeight(.bold)
                                }
                                .font(.subheadline)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(Color.red.opacity(0.15))
                                .foregroundColor(.red)
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(18)
                        .liquidGlass(cornerRadius: 26)
                    }
                    .padding(16)
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                        .fontWeight(.bold)
                        .foregroundColor(accent)
                }
            }
        }
        .preferredColorScheme(settings.isLightMode ? .light : .dark)
    }

    private func sectionTitle(_ title: String, icon: String) -> some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint
        return HStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundColor(accent)
            Text(title)
                .font(.headline.weight(.bold))
                .foregroundColor(settings.theme.primaryText(isLight: isLight))
        }
    }

    private func modeCard(title: String, icon: String, selected: Bool, action: @escaping () -> Void) -> some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint
        return Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .foregroundColor(selected ? .white : accent)
                Text(title)
                    .font(.subheadline.weight(.bold))
                    .foregroundColor(selected ? .white : settings.theme.primaryText(isLight: isLight))
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(selected ? AnyShapeStyle(settings.theme.accentGradient) : AnyShapeStyle(Color.primary.opacity(0.06)))
            )
        }
        .buttonStyle(.plain)
    }

    private func sliderRow(title: String, valueText: String, value: Binding<Double>, range: ClosedRange<Double>, step: Double) -> some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint
        return VStack(spacing: 4) {
            HStack {
                Text(title)
                    .font(.subheadline.weight(.medium))
                    .foregroundColor(settings.theme.primaryText(isLight: isLight))
                Spacer()
                Text(valueText)
                    .font(.caption.weight(.bold).monospacedDigit())
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(accent.opacity(0.16))
                    .foregroundColor(accent)
                    .clipShape(Capsule())
            }
            Slider(value: value, in: range, step: step)
                .tint(accent)
        }
    }

    private func navRow(title: String, subtitle: String, icon: String) -> some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint
        return HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title3)
                .foregroundColor(accent)
                .frame(width: 34, height: 34)
                .background(accent.opacity(0.15))
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline.weight(.bold))
                    .foregroundColor(settings.theme.primaryText(isLight: isLight))
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(settings.theme.secondaryText(isLight: isLight))
            }
            Spacer()
            Image(systemName: "chevron.right")
                .font(.caption.weight(.bold))
                .foregroundColor(settings.theme.secondaryText(isLight: isLight))
        }
        .padding(12)
        .background(Color.primary.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

struct PrivacyPolicyView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    var body: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Privacy Policy")
                    .font(.largeTitle.weight(.bold))
                Text("Effective Date: October 15, 2026")
                    .font(.subheadline)
                    .foregroundColor(settings.theme.secondaryText(isLight: isLight))

                Text("1. 100% On-Device Storage")
                    .font(.headline)
                    .foregroundColor(accent)
                Text("All scripts, cue tags, recorded videos, and preferences are saved locally on your iPhone or iPad. Teleprompter never uploads or transmits your scripts or videos to external servers.")

                Text("2. Camera & Microphone")
                    .font(.headline)
                    .foregroundColor(accent)
                Text("Camera previews, video recordings, video trimming, and voice-synced scrolling run strictly on your device using Apple AVFoundation and Speech frameworks.")

                Text("3. Zero Analytics or Tracking")
                    .font(.headline)
                    .foregroundColor(accent)
                Text("Teleprompter contains no third-party analytics, advertising SDKs, or tracking.")
            }
            .foregroundColor(settings.theme.primaryText(isLight: isLight))
            .padding(24)
        }
        .background(settings.theme.backgroundColor(isLight: isLight).ignoresSafeArea())
        .navigationTitle("Privacy Policy")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct TermsOfServiceView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    var body: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Terms of Use")
                    .font(.largeTitle.weight(.bold))
                Text("Last Updated: October 15, 2026")
                    .font(.subheadline)
                    .foregroundColor(settings.theme.secondaryText(isLight: isLight))

                Text("1. Usage & Ownership")
                    .font(.headline)
                    .foregroundColor(accent)
                Text("You retain full ownership and copyright of all scripts and video recordings produced with Teleprompter.")

                Text("2. Local Backups")
                    .font(.headline)
                    .foregroundColor(accent)
                Text("Because Teleprompter operates completely offline without cloud accounts, please keep regular backups of your scripts and saved video files.")

                Text("3. Warranty Disclaimer")
                    .font(.headline)
                    .foregroundColor(accent)
                Text("Teleprompter is provided 'as is' without warranty of any kind, express or implied.")
            }
            .foregroundColor(settings.theme.primaryText(isLight: isLight))
            .padding(24)
        }
        .background(settings.theme.backgroundColor(isLight: isLight).ignoresSafeArea())
        .navigationTitle("Terms of Use")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct AboutDeveloperView: View {
    @EnvironmentObject var settings: TeleprompterSettings
    var body: some View {
        let isLight = settings.isLightMode
        let accent = settings.theme.accentTint
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                HStack(spacing: 16) {
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .fill(settings.theme.accentGradient)
                        .frame(width: 64, height: 64)
                        .overlay(
                            Image(systemName: "viewfinder.circle.fill")
                                .font(.system(size: 32))
                                .foregroundColor(.white)
                        )
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Teleprompter")
                            .font(.title2.weight(.bold))
                            .foregroundColor(settings.theme.primaryText(isLight: isLight))
                        Text("Version 0.0.1 • Universal iOS & iPadOS")
                            .font(.subheadline)
                            .foregroundColor(settings.theme.secondaryText(isLight: isLight))
                    }
                }

                Divider()

                Text("Created by muneebwanee")
                    .font(.headline)
                    .foregroundColor(accent)

                Text("Designed with a minimalist Liquid Glass & Vector Motion interface for iPad and iPhone creators, speakers, and studios.")
                    .foregroundColor(settings.theme.secondaryText(isLight: isLight))

                if let url = URL(string: "https://github.com/muneebwanee") {
                    Link(destination: url) {
                        HStack {
                            Image(systemName: "link")
                            Text("github.com/muneebwanee")
                                .fontWeight(.semibold)
                            Spacer()
                            Image(systemName: "arrow.up.right")
                        }
                        .foregroundColor(settings.theme.primaryText(isLight: isLight))
                        .padding(16)
                        .liquidGlass(cornerRadius: 18, isHighlighted: true)
                    }
                }
            }
            .padding(24)
        }
        .background(settings.theme.backgroundColor(isLight: isLight).ignoresSafeArea())
        .navigationTitle("About")
        .navigationBarTitleDisplayMode(.inline)
    }
}
