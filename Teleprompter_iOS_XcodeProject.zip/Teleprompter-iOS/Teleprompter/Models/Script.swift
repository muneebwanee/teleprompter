import Foundation
import SwiftUI

struct CueMarker: Identifiable, Hashable {
    let id = UUID()
    let label: String
    let lineIndex: Int
}

struct ScriptItem: Identifiable, Codable, Hashable {
    var id: UUID = UUID()
    var title: String
    var category: String
    var content: String
    var targetWPM: Int
    var lastModified: Date
    var isPinned: Bool
    var notes: String

    var wordCount: Int {
        content
            .components(separatedBy: .whitespacesAndNewlines)
            .filter { !$0.isEmpty && !$0.hasPrefix("[") }
            .count
    }

    var estimatedDurationSeconds: Int {
        guard targetWPM > 0 else { return 0 }
        let baseSeconds = Int((Double(wordCount) / Double(targetWPM)) * 60.0)
        let pauseCount = content.components(separatedBy: "[PAUSE]").count - 1
        return baseSeconds + (max(0, pauseCount) * 2)
    }

    var formattedDuration: String {
        let total = estimatedDurationSeconds
        let mins = total / 60
        let secs = total % 60
        return String(format: "%d:%02d", mins, secs)
    }

    var paragraphs: [String] {
        content
            .replacingOccurrences(of: "\r\n", with: "\n")
            .components(separatedBy: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
    }

    mutating func formatShortLines() {
        let raw = content.replacingOccurrences(of: "\n\n", with: "\n")
        let sentences = raw
            .replacingOccurrences(of: ". ", with: ".\n")
            .replacingOccurrences(of: "? ", with: "?\n")
            .replacingOccurrences(of: "! ", with: "!\n")
        content = sentences
        lastModified = Date()
    }
}

@MainActor
final class ScriptStore: ObservableObject {
    @Published var scripts: [ScriptItem] = [] {
        didSet { save() }
    }
    @Published var selectedScriptID: UUID?

    private let storageKey = "teleprompter_scripts_v1"

    init() {
        load()
        if scripts.isEmpty {
            scripts = Self.sampleScripts
            selectedScriptID = scripts.first?.id
        }
    }

    var selectedScript: ScriptItem? {
        get {
            if let id = selectedScriptID, let found = scripts.first(where: { $0.id == id }) {
                return found
            }
            return scripts.first
        }
        set {
            guard let updated = newValue,
                  let idx = scripts.firstIndex(where: { $0.id == updated.id }) else { return }
            scripts[idx] = updated
        }
    }

    func createScript(title: String = "New Script", category: String = "Keynote") -> ScriptItem {
        let newScript = ScriptItem(
            title: title,
            category: category,
            content: "Welcome to Teleprompter.\n\n[PAUSE]\n\nType or paste your script here. Use [PAUSE] for breath cues and [EMPHASIS] to highlight key talking points while you record.",
            targetWPM: 140,
            lastModified: Date(),
            isPinned: false,
            notes: "Keep your eyes near the top camera lens."
        )
        scripts.insert(newScript, at: 0)
        selectedScriptID = newScript.id
        return newScript
    }

    func deleteScript(id: UUID) {
        scripts.removeAll { $0.id == id }
        if selectedScriptID == id {
            selectedScriptID = scripts.first?.id
        }
    }

    func duplicateScript(_ script: ScriptItem) {
        var copy = script
        copy.id = UUID()
        copy.title = "\(script.title) (Copy)"
        copy.lastModified = Date()
        scripts.insert(copy, at: 0)
        selectedScriptID = copy.id
    }

    private func save() {
        if let data = try? JSONEncoder().encode(scripts) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([ScriptItem].self, from: data) else { return }
        scripts = decoded
        selectedScriptID = scripts.first?.id
    }

    static let sampleScripts: [ScriptItem] = [
        ScriptItem(
            title: "Product Launch Keynote",
            category: "Keynote",
            content: """
            Good morning everyone, and thank you for joining us today.
            [PAUSE]
            Over the past year, our team asked a simple question: how can creators deliver studio-grade presentations from an iPhone or iPad without losing natural eye contact?
            [EMPHASIS] Today, we are introducing Teleprompter — a clean, minimalist reading studio built for speed and clarity.
            [PAUSE]
            Notice how this script stays anchored right near the camera lens. Whether you are filming a video, presenting live, or using a mirror glass rig, your eyes stay locked on your audience.
            [SLOW]
            With Follow Voice mode, when you pause to speak freely, the script waits for you. When you continue, it scrolls smoothly on your device.
            [PAUSE]
            Let's jump into a live look at what you can create today.
            """,
            targetWPM: 145,
            lastModified: Date(),
            isPinned: true,
            notes: "Smile on opening line. Pause 2 seconds after introducing Teleprompter."
        ),
        ScriptItem(
            title: "Creator Studio Episode #42",
            category: "Video",
            content: """
            Hey everyone! Welcome back to the channel.
            [PAUSE]
            In today's video, we are breaking down the 3 simple framing and lighting habits that immediately make mobile video look like a cinema camera.
            [EMPHASIS] First: keep your teleprompter text right near the top camera lens.
            Second: use a dark background in dim rooms so your screen doesn't cast a bright glare on your glasses.
            [PAUSE]
            Third: add [PAUSE] tags so your delivery sounds natural and relaxed.
            Tap Record whenever you are ready, and let's get started!
            """,
            targetWPM: 155,
            lastModified: Date().addingTimeInterval(-3600 * 12),
            isPinned: false,
            notes: "Use Front Camera with small preview near top lens."
        ),
        ScriptItem(
            title: "Weekly Team Update",
            category: "Update",
            content: """
            Hello team and partners. Here is our quick three-minute update for this week.
            [PAUSE]
            First, customer satisfaction reached a new high across our mobile apps, thanks to smoother camera recording and built-in video trimming.
            [EMPHASIS] Second, every script and video take stays 100% private on your iPhone or iPad.
            [PAUSE]
            Thank you for your hard work and dedication this week.
            """,
            targetWPM: 135,
            lastModified: Date().addingTimeInterval(-3600 * 36),
            isPinned: false,
            notes: "Turn on Flip Left-Right when using a mirror hood."
        )
    ]
}
