import SwiftUI

enum PrompterTheme: String, CaseIterable, Codable, Identifiable {
    case actionOrange = "Orange"
    case solarGold = "Gold"
    case cinemaRed = "Red"
    case emeraldGreen = "Green"
    case oceanBlue = "Blue"
    case oledBlack = "Pure Black"

    var id: String { rawValue }

    var subtitle: String {
        switch self {
        case .actionOrange: return "Warm Studio Glow"
        case .solarGold: return "Golden Broadcast"
        case .cinemaRed: return "Director Crimson"
        case .emeraldGreen: return "Calm Studio Mint"
        case .oceanBlue: return "Clean Sapphire"
        case .oledBlack: return "True Zero-Glow OLED"
        }
    }

    func backgroundColor(isLight: Bool) -> Color {
        if isLight {
            switch self {
            case .actionOrange: return Color(red: 0.96, green: 0.95, blue: 0.93)
            case .solarGold: return Color(red: 0.97, green: 0.96, blue: 0.92)
            case .cinemaRed: return Color(red: 0.97, green: 0.94, blue: 0.94)
            case .emeraldGreen: return Color(red: 0.93, green: 0.97, blue: 0.95)
            case .oceanBlue: return Color(red: 0.93, green: 0.95, blue: 0.98)
            case .oledBlack: return Color(red: 0.94, green: 0.94, blue: 0.96)
            }
        } else {
            switch self {
            case .actionOrange: return Color(red: 0.035, green: 0.025, blue: 0.02)
            case .solarGold: return Color(red: 0.04, green: 0.035, blue: 0.015)
            case .cinemaRed: return Color(red: 0.045, green: 0.018, blue: 0.022)
            case .emeraldGreen: return Color(red: 0.018, green: 0.04, blue: 0.028)
            case .oceanBlue: return Color(red: 0.018, green: 0.028, blue: 0.05)
            case .oledBlack: return Color.black
            }
        }
    }

    func cardSurface(isLight: Bool) -> Color {
        if isLight {
            return Color.white.opacity(0.78)
        } else {
            switch self {
            case .actionOrange: return Color(red: 0.11, green: 0.08, blue: 0.07).opacity(0.72)
            case .solarGold: return Color(red: 0.11, green: 0.09, blue: 0.05).opacity(0.72)
            case .cinemaRed: return Color(red: 0.12, green: 0.06, blue: 0.07).opacity(0.72)
            case .emeraldGreen: return Color(red: 0.06, green: 0.11, blue: 0.08).opacity(0.72)
            case .oceanBlue: return Color(red: 0.06, green: 0.08, blue: 0.13).opacity(0.72)
            case .oledBlack: return Color(red: 0.07, green: 0.07, blue: 0.09).opacity(0.85)
            }
        }
    }

    func primaryText(isLight: Bool) -> Color {
        isLight ? Color(red: 0.08, green: 0.08, blue: 0.11) : Color(red: 0.98, green: 0.97, blue: 0.96)
    }

    func secondaryText(isLight: Bool) -> Color {
        isLight ? Color(red: 0.38, green: 0.38, blue: 0.44) : Color(red: 0.68, green: 0.68, blue: 0.74)
    }

    var accentTint: Color {
        switch self {
        case .actionOrange: return Color(red: 1.0, green: 0.42, blue: 0.0)
        case .solarGold: return Color(red: 1.0, green: 0.72, blue: 0.0)
        case .cinemaRed: return Color(red: 1.0, green: 0.23, blue: 0.19)
        case .emeraldGreen: return Color(red: 0.19, green: 0.82, blue: 0.35)
        case .oceanBlue: return Color(red: 0.04, green: 0.52, blue: 1.0)
        case .oledBlack: return Color(red: 1.0, green: 0.52, blue: 0.15)
        }
    }

    var accentGradient: LinearGradient {
        switch self {
        case .actionOrange:
            return LinearGradient(colors: [Color(red: 1.0, green: 0.55, blue: 0.15), Color(red: 0.90, green: 0.28, blue: 0.0)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .solarGold:
            return LinearGradient(colors: [Color(red: 1.0, green: 0.82, blue: 0.20), Color(red: 0.88, green: 0.56, blue: 0.0)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .cinemaRed:
            return LinearGradient(colors: [Color(red: 1.0, green: 0.38, blue: 0.32), Color(red: 0.82, green: 0.12, blue: 0.12)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .emeraldGreen:
            return LinearGradient(colors: [Color(red: 0.28, green: 0.88, blue: 0.45), Color(red: 0.10, green: 0.62, blue: 0.25)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .oceanBlue:
            return LinearGradient(colors: [Color(red: 0.25, green: 0.68, blue: 1.0), Color(red: 0.02, green: 0.38, blue: 0.88)], startPoint: .topLeading, endPoint: .bottomTrailing)
        case .oledBlack:
            return LinearGradient(colors: [Color(red: 1.0, green: 0.58, blue: 0.22), Color(red: 0.85, green: 0.32, blue: 0.0)], startPoint: .topLeading, endPoint: .bottomTrailing)
        }
    }
}

enum PrompterFontDesign: String, CaseIterable, Codable, Identifiable {
    case sans = "Clean Sans"
    case rounded = "Soft Rounded"
    case serif = "Book Serif"
    case mono = "Studio Mono"

    var id: String { rawValue }

    var swiftUIFontDesign: Font.Design {
        switch self {
        case .sans: return .default
        case .rounded: return .rounded
        case .serif: return .serif
        case .mono: return .monospaced
        }
    }
}

enum ScrollMode: String, CaseIterable, Codable, Identifiable {
    case continuous = "Smooth Speed"
    case voiceActivated = "Follow Voice"
    case voiceLevel = "Sound Trigger"
    case manual = "Manual Touch"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .continuous: return "speedometer"
        case .voiceActivated: return "waveform.badge.mic"
        case .voiceLevel: return "mic.fill"
        case .manual: return "hand.draw.fill"
        }
    }
}

struct LiquidGlassModifier: ViewModifier {
    @EnvironmentObject var settings: TeleprompterSettings
    var cornerRadius: CGFloat = 24
    var isHighlighted: Bool = false

    func body(content: Content) -> some View {
        let accent = settings.theme.accentTint
        let isLight = settings.isLightMode
        content
            .background(.ultraThinMaterial)
            .background(
                LinearGradient(
                    colors: isHighlighted
                        ? [accent.opacity(isLight ? 0.20 : 0.28), settings.theme.cardSurface(isLight: isLight)]
                        : [settings.theme.cardSurface(isLight: isLight), settings.theme.cardSurface(isLight: isLight).opacity(0.85)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(
                        LinearGradient(
                            colors: isHighlighted
                                ? [accent.opacity(0.85), accent.opacity(0.25)]
                                : [Color.white.opacity(isLight ? 0.65 : 0.18), Color.white.opacity(isLight ? 0.25 : 0.04)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: isHighlighted ? 1.5 : 1.0
                    )
            )
            .shadow(color: (isHighlighted ? accent : Color.black).opacity(isLight ? 0.10 : 0.38), radius: isHighlighted ? 18 : 14, x: 0, y: 8)
    }
}

extension View {
    func liquidGlass(cornerRadius: CGFloat = 24, isHighlighted: Bool = false) -> some View {
        modifier(LiquidGlassModifier(cornerRadius: cornerRadius, isHighlighted: isHighlighted))
    }
}

@MainActor
final class TeleprompterSettings: ObservableObject {
    @AppStorage("tp_fontSize") var fontSize: Double = 42.0
    @AppStorage("tp_lineSpacing") var lineSpacing: Double = 14.0
    @AppStorage("tp_sideMargin") var horizontalMargin: Double = 32.0
    @AppStorage("tp_scrollSpeed") var wordsPerMinute: Double = 145.0
    @AppStorage("tp_mirrorH") var mirrorHorizontal: Bool = false
    @AppStorage("tp_mirrorV") var mirrorVertical: Bool = false
    @AppStorage("tp_eyeLinePosition") var eyeLineVerticalRatio: Double = 0.28
    @AppStorage("tp_showEyeLine") var showEyeLineGuide: Bool = true
    @AppStorage("tp_dimUnread") var focusDimmingEnabled: Bool = true
    @AppStorage("tp_easyRead") var easyReadEnabled: Bool = false
    @AppStorage("tp_autoPauseTag") var autoWaitOnPauseTag: Bool = true
    @AppStorage("tp_countdownSeconds") var countdownSeconds: Int = 3
    @AppStorage("tp_showCameraPiP") var showCameraPreview: Bool = true
    @AppStorage("tp_fullScreenCamera") var fullScreenCameraStage: Bool = false
    @AppStorage("tp_showTimecode") var showElapsedTimer: Bool = true
    @AppStorage("tp_showCuePills") var renderCueBadges: Bool = true
    @AppStorage("tp_isLightMode") var isLightMode: Bool = false
    @AppStorage("tp_theme") var selectedThemeRaw: String = PrompterTheme.actionOrange.rawValue
    @AppStorage("tp_fontDesign") var selectedFontRaw: String = PrompterFontDesign.sans.rawValue
    @AppStorage("tp_scrollMode") var scrollModeRaw: String = ScrollMode.continuous.rawValue

    var theme: PrompterTheme {
        get { PrompterTheme(rawValue: selectedThemeRaw) ?? .actionOrange }
        set {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
                selectedThemeRaw = newValue.rawValue
                objectWillChange.send()
            }
        }
    }

    var fontDesign: PrompterFontDesign {
        get { PrompterFontDesign(rawValue: selectedFontRaw) ?? .sans }
        set {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
                selectedFontRaw = newValue.rawValue
                objectWillChange.send()
            }
        }
    }

    var scrollMode: ScrollMode {
        get { ScrollMode(rawValue: scrollModeRaw) ?? .continuous }
        set {
            withAnimation(.spring(response: 0.28, dampingFraction: 0.8)) {
                scrollModeRaw = newValue.rawValue
                objectWillChange.send()
            }
        }
    }

    func resetToDefaults() {
        withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) {
            fontSize = 42.0
            lineSpacing = 14.0
            horizontalMargin = 32.0
            wordsPerMinute = 145.0
            mirrorHorizontal = false
            mirrorVertical = false
            eyeLineVerticalRatio = 0.28
            showEyeLineGuide = true
            focusDimmingEnabled = true
            easyReadEnabled = false
            autoWaitOnPauseTag = true
            countdownSeconds = 3
            showCameraPreview = true
            fullScreenCameraStage = false
            isLightMode = false
            selectedThemeRaw = PrompterTheme.actionOrange.rawValue
            selectedFontRaw = PrompterFontDesign.sans.rawValue
            scrollModeRaw = ScrollMode.continuous.rawValue
        }
    }
}
