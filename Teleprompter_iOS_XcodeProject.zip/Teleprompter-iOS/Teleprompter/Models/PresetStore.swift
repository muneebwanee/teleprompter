import SwiftUI

struct StudioPreset: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var subtitle: String
    var icon: String
    var wpm: Double
    var fontSize: Double
    var overlayMode: Bool
    var mirrorX: Bool
    var easyRead: Bool
    var cameraLens: String
}

@MainActor
final class PresetStore: ObservableObject {
    @Published var presets: [StudioPreset] = [
        StudioPreset(id: "keynote", name: "Keynote Stage", subtitle: "44pt • 145 WPM • Clean View", icon: "mic.fill", wpm: 145, fontSize: 44, overlayMode: false, mirrorX: false, easyRead: false, cameraLens: "1x"),
        StudioPreset(id: "vlog_overlay", name: "Camera Backdrop", subtitle: "38pt • 155 WPM • Full Camera", icon: "camera.viewfinder", wpm: 155, fontSize: 38, overlayMode: true, mirrorX: false, easyRead: true, cameraLens: "1x"),
        StudioPreset(id: "beamsplitter", name: "Mirror Glass Rig", subtitle: "52pt • 140 WPM • Flip Left-Right", icon: "arrow.left.and.right.righttriangle.left.righttriangle.right.fill", wpm: 140, fontSize: 52, overlayMode: false, mirrorX: true, easyRead: false, cameraLens: "2x"),
        StudioPreset(id: "vertical_reels", name: "Short Vertical Video", subtitle: "36pt • 165 WPM • Easy Read", icon: "rectangle.portrait.fill", wpm: 165, fontSize: 36, overlayMode: true, mirrorX: false, easyRead: true, cameraLens: "1x")
    ]
}
