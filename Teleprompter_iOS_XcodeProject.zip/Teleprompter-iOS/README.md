# Teleprompter — Minimalist iOS & iPadOS Studio Teleprompter & Camera

[![Platform](https://img.shields.io/badge/Platform-iOS%2016%2B%20%7C%20iPadOS%2016%2B-FF6B00?style=flat-square)](https://github.com/muneebwanee)
[![Version](https://img.shields.io/badge/Version-0.0.1-FF8E3C?style=flat-square)](https://github.com/muneebwanee)
[![Offline](https://img.shields.io/badge/Privacy-100%25%20Offline-10B981?style=flat-square)](https://github.com/muneebwanee)
[![License](https://img.shields.io/badge/License-MIT-blue?style=flat-square)](LICENSE)

**Teleprompter** (`v0.0.1`) is a fast, 100% offline teleprompter, camera studio, and video trimmer app for **iPhone and iPad**, designed with a minimalist **Liquid Glass** interface, smooth vector motion graphics, front and back camera recording, post-capture video trimming, voice-synced scrolling, and Home Screen widgets.

Created by **[muneebwanee](https://github.com/muneebwanee)**.

---

## Features

- **Minimalist iOS & iPadOS Liquid Glass Design**
  - Switch in real time between **Dark Mode** and **Light Mode** with 6 live studio color themes (*Orange*, *Gold*, *Red*, *Green*, *Blue*, and *Pure Black*) that animate across the entire app.
  - Custom animated SVG vector art headers on script cards and a live 60fps harmonic wave ribbon that reacts to your reading speed.
- **Built-In Front & Back Camera Studio**
  - Live `AVCaptureVideoPreviewLayer` viewfinder with instant switching between **Front Camera** and **Back Camera** (`1x`, `2x`, `3x` zoom) both inside the dedicated **Camera** studio and directly inside the full-screen **Reading Screen**.
  - Choose between a **Small Camera (PiP)** window near the top lens or a **Full-Screen Camera Backdrop** behind your scrolling script.
- **Post-Capture Video Editor & Trimmer**
  - Immediately after recording a take, the built-in **Video Editor & Trimmer** opens so you can preview your video, drag **Start Trim** and **End Trim** handles, apply on-device lossless trimming (`AVAssetExportSession`), adjust playback speed (`0.5x`–`2x`), **Save to Photos**, **Save to Files**, or **Share**.
- **Interactive Reading Modes & Voice Scroll**
  - Switch anytime between **Smooth Speed**, **Follow Voice** (on-device speech recognition), **Sound Trigger**, and **Manual Touch** using the always-visible bottom mode bar.
  - **Listen Aloud**: Hear your iPhone or iPad read your script out loud before you start recording.
  - **Short Lines**: Break long paragraphs into short, easy-to-read lines with one tap.
- **Reading Aids & Mirror Glass Support**
  - **Easy Read**: Bolds words for faster eye tracking.
  - **Flip Left-Right / Flip Up-Down**: Mirrors text horizontally or vertically for physical beam-splitter teleprompter glass rigs.
- **100% Offline & Private**
  - Every script, video clip, and setting stays on your device. No accounts, no cloud servers, and no tracking.

---

## Repository Structure

```text
teleprompter/
├── Teleprompter.xcodeproj/                # Universal iOS & iPadOS 16.0+ Xcode Project (Format 56)
├── project.yml                            # XcodeGen project specification
├── build_ipa.sh                           # Local macOS script to build unsigned .ipa
├── .github/workflows/build-ipa.yml        # GitHub Actions cloud .ipa builder & release publisher
├── Teleprompter_App.html                  # Standalone offline iOS/iPadOS WebApp
└── Teleprompter/
    ├── Info.plist                         # Camera, Microphone, Speech, Photos & Bluetooth permissions
    ├── Assets.xcassets/AppIcon.appiconset # Universal iPhone & iPad App Icons (20pt–1024pt)
    ├── TeleprompterApp.swift              # App entry point & live theme environment
    ├── Models/
    │   ├── Script.swift                   # Script storage, reading time math & Short Lines formatter
    │   ├── PresetStore.swift              # Quick-start camera & reading presets
    │   └── TeleprompterSettings.swift     # Real-time 6-Theme engine, Dark/Light mode & Liquid Glass
    ├── Services/
    │   ├── VoiceTrackEngine.swift         # On-device voice recognition, audio level & Listen Aloud
    │   └── CameraRecordingManager.swift   # Live AVCaptureVideoPreviewLayer & video trimming engine
    ├── Views/
    │   ├── ContentView.swift              # Main navigation, vector wave header & script library
    │   ├── ScriptEditorView.swift         # Script editor, Listen Aloud, Short Lines & cue bar
    │   ├── BroadcastCameraView.swift      # Built-in iOS camera & floating script overlay
    │   ├── TeleprompterView.swift         # Full-screen reading stage, Mode bar & Front/Back camera
    │   ├── VideoClipEditorView.swift      # Post-capture video editor, trimmer, Save to Photos & Files
    │   ├── VectorMotionArtView.swift      # 60fps SwiftUI Canvas vector wave graphics
    │   └── SettingsDrawerView.swift       # Animated Liquid Glass Settings, Privacy, Terms & About
    └── TeleprompterWidgets/
        └── TeleprompterWidgetBundle.swift # Home Screen & Lock Screen WidgetKit extension
```

---

## Installation & Sideloading

1. Go to the **Releases** page of this repository and download **`Teleprompter-iOS-Universal.ipa`** (`v0.0.1`).
2. Install the `.ipa` on your iPad or iPhone using **SideStore**, **AltStore**, **Feather**, or **Sideloadly**.
3. Or open **`Teleprompter_App.html`** in Safari on your iPad or iPhone and tap **Share → Add to Home Screen** for instant offline use.

---

## Privacy & License

- **100% On-Device Privacy**: All scripts, settings, and camera/microphone recordings stay on your device.
- **Author**: **[muneebwanee](https://github.com/muneebwanee)**
- **License**: Released under the MIT License.
